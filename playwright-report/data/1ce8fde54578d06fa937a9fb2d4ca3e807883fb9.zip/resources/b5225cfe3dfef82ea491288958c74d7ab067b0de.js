;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="586ef570-6203-a370-c4b9-ab0f9c1c5394")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/instrumentation-client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// This file configures the initialization of Sentry on the client.
// The added config here will be used whenever a users loads a page in their browser.
// https://docs.sentry.io/platforms/javascript/guides/nextjs/
__turbopack_context__.s([
    "onRouterTransitionStart",
    ()=>onRouterTransitionStart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@sentry/nextjs/build/esm/client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2d$internal$2f$replay$2f$build$2f$npm$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sentry-internal/replay/build/npm/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$routing$2f$appRouterRoutingInstrumentation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sentry/nextjs/build/esm/client/routing/appRouterRoutingInstrumentation.js [app-client] (ecmascript)");
globalThis["_sentryRouteManifest"] = "{\"dynamicRoutes\":[{\"path\":\"/dashboard/applications/:id\",\"regex\":\"^/dashboard/applications/([^/]+)$\",\"paramNames\":[\"id\"],\"hasOptionalPrefix\":false},{\"path\":\"/dashboard/jobs/:id\",\"regex\":\"^/dashboard/jobs/([^/]+)$\",\"paramNames\":[\"id\"],\"hasOptionalPrefix\":false},{\"path\":\"/dashboard/jobs/:id/apply\",\"regex\":\"^/dashboard/jobs/([^/]+)/apply$\",\"paramNames\":[\"id\"],\"hasOptionalPrefix\":false},{\"path\":\"/dashboard/jobs/:id/edit\",\"regex\":\"^/dashboard/jobs/([^/]+)/edit$\",\"paramNames\":[\"id\"],\"hasOptionalPrefix\":false},{\"path\":\"/dashboard/messages/:id\",\"regex\":\"^/dashboard/messages/([^/]+)$\",\"paramNames\":[\"id\"],\"hasOptionalPrefix\":false},{\"path\":\"/dashboard/profiles/:id\",\"regex\":\"^/dashboard/profiles/([^/]+)$\",\"paramNames\":[\"id\"],\"hasOptionalPrefix\":false}],\"staticRoutes\":[{\"path\":\"/\"},{\"path\":\"/admin\"},{\"path\":\"/admin/analytics\"},{\"path\":\"/admin/certifications\"},{\"path\":\"/admin/dashboard\"},{\"path\":\"/admin/moderation\"},{\"path\":\"/admin/monitoring\"},{\"path\":\"/admin/settings\"},{\"path\":\"/admin/users\"},{\"path\":\"/dashboard/applications\"},{\"path\":\"/dashboard/feed\"},{\"path\":\"/dashboard/jobs\"},{\"path\":\"/dashboard/jobs/new\"},{\"path\":\"/dashboard/messages\"},{\"path\":\"/dashboard/notifications\"},{\"path\":\"/dashboard/profile\"},{\"path\":\"/dashboard/profile/certifications\"},{\"path\":\"/dashboard/profile/edit\"},{\"path\":\"/dashboard/profile/education\"},{\"path\":\"/dashboard/profile/experience\"},{\"path\":\"/dashboard/settings\"},{\"path\":\"/dashboard/subscription\"},{\"path\":\"/dashboard/test-sentry\"},{\"path\":\"/dashboard/workers\"},{\"path\":\"/login\"},{\"path\":\"/onboarding\"},{\"path\":\"/pricing\"},{\"path\":\"/sentry-example-page\"},{\"path\":\"/signup\"}],\"isrRoutes\":[]}";
globalThis["_sentryNextJsVersion"] = "16.0.10";
globalThis["_sentryRewritesTunnelPath"] = "/monitoring";
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["init"]({
    dsn: "https://ad6e07c9bc730e345b8354905beba907@o4509613448757248.ingest.us.sentry.io/4510613324365824",
    integrations: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2d$internal$2f$replay$2f$build$2f$npm$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replayIntegration"]()
    ],
    // Session Replay
    replaysSessionSampleRate: 0.1,
    replaysOnErrorSampleRate: 1.0,
    // Define how likely traces are sampled. Adjust this value in production, or use tracesSampler for greater control.
    tracesSampleRate: 1,
    // Enable logs to be sent to Sentry
    enableLogs: true,
    // Enable sending user PII (Personally Identifiable Information)
    // https://docs.sentry.io/platforms/javascript/guides/nextjs/configuration/options/#sendDefaultPii
    sendDefaultPii: true
});
const onRouterTransitionStart = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$routing$2f$appRouterRoutingInstrumentation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureRouterTransitionStart"];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=586ef570-6203-a370-c4b9-ab0f9c1c5394
//# sourceMappingURL=instrumentation-client_ts_15a74a80._.js.map