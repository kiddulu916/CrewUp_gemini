;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="fb148e41-ad6d-2e04-fe3c-2e7397667f4f")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/features/profile/actions/data:75b39e [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"402e58cbcf10e3538e991408f1afe55a11ea9741e8":"updateProfileLocation"},"features/profile/actions/profile-actions.ts",""] */ __turbopack_context__.s([
    "updateProfileLocation",
    ()=>updateProfileLocation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var updateProfileLocation = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("402e58cbcf10e3538e991408f1afe55a11ea9741e8", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateProfileLocation"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcHJvZmlsZS1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcblxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQC9saWIvc3VwYWJhc2Uvc2VydmVyJztcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSAnbmV4dC9jYWNoZSc7XG5pbXBvcnQgeyByZWRpcmVjdCB9IGZyb20gJ25leHQvbmF2aWdhdGlvbic7XG5pbXBvcnQgeyBjb29raWVzIH0gZnJvbSAnbmV4dC9oZWFkZXJzJztcblxuZXhwb3J0IHR5cGUgUHJvZmlsZVVwZGF0ZURhdGEgPSB7XG4gIG5hbWU6IHN0cmluZztcbiAgdHJhZGU6IHN0cmluZztcbiAgc3ViX3RyYWRlPzogc3RyaW5nO1xuICBsb2NhdGlvbjogc3RyaW5nO1xuICBjb29yZHM/OiB7IGxhdDogbnVtYmVyOyBsbmc6IG51bWJlciB9IHwgbnVsbDtcbiAgcGhvbmU/OiBzdHJpbmc7XG4gIGJpbz86IHN0cmluZztcbiAgZW1wbG95ZXJfdHlwZT86ICdjb250cmFjdG9yJyB8ICdyZWNydWl0ZXInO1xuICBwcm9maWxlX2ltYWdlX3VybD86IHN0cmluZyB8IG51bGw7XG59O1xuXG5leHBvcnQgdHlwZSBQcm9maWxlUmVzdWx0ID0ge1xuICBzdWNjZXNzOiBib29sZWFuO1xuICBlcnJvcj86IHN0cmluZztcbn07XG5cbi8qKlxuICogVXBkYXRlIHVzZXIgcHJvZmlsZVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlUHJvZmlsZShkYXRhOiBQcm9maWxlVXBkYXRlRGF0YSk6IFByb21pc2U8UHJvZmlsZVJlc3VsdD4ge1xuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudChhd2FpdCBjb29raWVzKCkpO1xuXG4gIGNvbnN0IHtcbiAgICBkYXRhOiB7IHVzZXIgfSxcbiAgICBlcnJvcjogYXV0aEVycm9yLFxuICB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XG5cbiAgaWYgKGF1dGhFcnJvciB8fCAhdXNlcikge1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ05vdCBhdXRoZW50aWNhdGVkJyB9O1xuICB9XG5cbiAgLy8gR2V0IGN1cnJlbnQgcHJvZmlsZSB0byBjaGVjayByb2xlXG4gIGNvbnN0IHsgZGF0YTogY3VycmVudFByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oJ3Byb2ZpbGVzJylcbiAgICAuc2VsZWN0KCdyb2xlJylcbiAgICAuZXEoJ2lkJywgdXNlci5pZClcbiAgICAuc2luZ2xlKCk7XG5cbiAgLy8gSWYgY29vcmRzIGFyZSBwcm92aWRlZCwgdXNlIHRoZSBQb3N0Z3JlcyBmdW5jdGlvbiBmb3IgcHJvcGVyIFBvc3RHSVMgY29udmVyc2lvblxuICBpZiAoZGF0YS5jb29yZHMgJiYgdHlwZW9mIGRhdGEuY29vcmRzLmxhdCA9PT0gJ251bWJlcicgJiYgdHlwZW9mIGRhdGEuY29vcmRzLmxuZyA9PT0gJ251bWJlcicpIHtcbiAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UucnBjKCd1cGRhdGVfcHJvZmlsZV9jb29yZHMnLCB7XG4gICAgICBwX3VzZXJfaWQ6IHVzZXIuaWQsXG4gICAgICBwX25hbWU6IGRhdGEubmFtZSxcbiAgICAgIHBfcm9sZTogY3VycmVudFByb2ZpbGU/LnJvbGUgfHwgJ3dvcmtlcicsXG4gICAgICBwX3RyYWRlOiBkYXRhLnRyYWRlLFxuICAgICAgcF9sb2NhdGlvbjogZGF0YS5sb2NhdGlvbixcbiAgICAgIHBfbG5nOiBkYXRhLmNvb3Jkcy5sbmcsXG4gICAgICBwX2xhdDogZGF0YS5jb29yZHMubGF0LFxuICAgICAgcF9iaW86IGRhdGEuYmlvIHx8IG51bGwsXG4gICAgICBwX3N1Yl90cmFkZTogZGF0YS5zdWJfdHJhZGUgfHwgbnVsbCxcbiAgICAgIHBfZW1wbG95ZXJfdHlwZTogY3VycmVudFByb2ZpbGU/LnJvbGUgPT09ICdlbXBsb3llcicgPyBkYXRhLmVtcGxveWVyX3R5cGUgfHwgbnVsbCA6IG51bGwsXG4gICAgfSk7XG5cbiAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogdXBkYXRlRXJyb3IubWVzc2FnZSB9O1xuICAgIH1cblxuICAgIC8vIFVwZGF0ZSBwaG9uZSBhbmQgcHJvZmlsZV9pbWFnZV91cmwgc2VwYXJhdGVseSBpZiBwcm92aWRlZCAobm90IGluIFJQQyBmdW5jdGlvbilcbiAgICBjb25zdCBleHRyYVVwZGF0ZXM6IGFueSA9IHt9O1xuICAgIGlmIChkYXRhLnBob25lKSB7XG4gICAgICBleHRyYVVwZGF0ZXMucGhvbmUgPSBkYXRhLnBob25lO1xuICAgIH1cbiAgICBpZiAoZGF0YS5wcm9maWxlX2ltYWdlX3VybCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBleHRyYVVwZGF0ZXMucHJvZmlsZV9pbWFnZV91cmwgPSBkYXRhLnByb2ZpbGVfaW1hZ2VfdXJsO1xuICAgIH1cblxuICAgIGlmIChPYmplY3Qua2V5cyhleHRyYVVwZGF0ZXMpLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IHsgZXJyb3I6IGV4dHJhRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKCdwcm9maWxlcycpXG4gICAgICAgIC51cGRhdGUoZXh0cmFVcGRhdGVzKVxuICAgICAgICAuZXEoJ2lkJywgdXNlci5pZCk7XG5cbiAgICAgIGlmIChleHRyYUVycm9yKSB7XG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXh0cmFFcnJvci5tZXNzYWdlIH07XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIElmIG5vIGNvb3JkcyBwcm92aWRlZCwgZG8gYSByZWd1bGFyIHVwZGF0ZSB3aXRob3V0IGNvb3Jkc1xuICAgIGNvbnN0IHVwZGF0ZURhdGE6IGFueSA9IHtcbiAgICAgIG5hbWU6IGRhdGEubmFtZSxcbiAgICAgIHRyYWRlOiBkYXRhLnRyYWRlLFxuICAgICAgbG9jYXRpb246IGRhdGEubG9jYXRpb24sXG4gICAgICBiaW86IGRhdGEuYmlvLFxuICAgIH07XG5cbiAgICAvLyBPbmx5IGluY2x1ZGUgcGhvbmUgaWYgcHJvdmlkZWRcbiAgICBpZiAoZGF0YS5waG9uZSkge1xuICAgICAgdXBkYXRlRGF0YS5waG9uZSA9IGRhdGEucGhvbmU7XG4gICAgfVxuXG4gICAgLy8gT25seSBzZXQgc3ViX3RyYWRlIGlmIHByb3ZpZGVkXG4gICAgaWYgKGRhdGEuc3ViX3RyYWRlKSB7XG4gICAgICB1cGRhdGVEYXRhLnN1Yl90cmFkZSA9IGRhdGEuc3ViX3RyYWRlO1xuICAgIH1cblxuICAgIC8vIE9ubHkgc2V0IGVtcGxveWVyX3R5cGUgZm9yIGVtcGxveWVyc1xuICAgIGlmIChjdXJyZW50UHJvZmlsZT8ucm9sZSA9PT0gJ2VtcGxveWVyJyAmJiBkYXRhLmVtcGxveWVyX3R5cGUpIHtcbiAgICAgIHVwZGF0ZURhdGEuZW1wbG95ZXJfdHlwZSA9IGRhdGEuZW1wbG95ZXJfdHlwZTtcbiAgICB9XG5cbiAgICAvLyBPbmx5IHNldCBwcm9maWxlX2ltYWdlX3VybCBpZiBwcm92aWRlZFxuICAgIGlmIChkYXRhLnByb2ZpbGVfaW1hZ2VfdXJsICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHVwZGF0ZURhdGEucHJvZmlsZV9pbWFnZV91cmwgPSBkYXRhLnByb2ZpbGVfaW1hZ2VfdXJsO1xuICAgIH1cblxuICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oJ3Byb2ZpbGVzJylcbiAgICAgIC51cGRhdGUodXBkYXRlRGF0YSlcbiAgICAgIC5lcSgnaWQnLCB1c2VyLmlkKTtcblxuICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiB1cGRhdGVFcnJvci5tZXNzYWdlIH07XG4gICAgfVxuICB9XG5cbiAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvcHJvZmlsZScpO1xuICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG59XG5cbi8qKlxuICogVXBkYXRlIHVzZXIncyBsb2NhdGlvbiBjb29yZGluYXRlcyAodXNlZCBmb3IgaW5pdGlhbCBsb2NhdGlvbiBjYXB0dXJlKVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlUHJvZmlsZUxvY2F0aW9uKGRhdGE6IHtcbiAgbG9jYXRpb246IHN0cmluZztcbiAgY29vcmRzOiB7IGxhdDogbnVtYmVyOyBsbmc6IG51bWJlciB9O1xufSk6IFByb21pc2U8eyBzdWNjZXNzOiBib29sZWFuOyBlcnJvcj86IHN0cmluZyB9PiB7XG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KGF3YWl0IGNvb2tpZXMoKSk7XG5cbiAgLy8gR2V0IGN1cnJlbnQgdXNlclxuICBjb25zdCB7XG4gICAgZGF0YTogeyB1c2VyIH0sXG4gICAgZXJyb3I6IGF1dGhFcnJvcixcbiAgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xuXG4gIGlmIChhdXRoRXJyb3IgfHwgIXVzZXIpIHtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdOb3QgYXV0aGVudGljYXRlZCcgfTtcbiAgfVxuXG4gIC8vIEdldCBjdXJyZW50IHByb2ZpbGUgZGF0YSBmaXJzdFxuICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oJ3Byb2ZpbGVzJylcbiAgICAuc2VsZWN0KCcqJylcbiAgICAuZXEoJ2lkJywgdXNlci5pZClcbiAgICAuc2luZ2xlKCk7XG5cbiAgaWYgKCFwcm9maWxlKSB7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnUHJvZmlsZSBub3QgZm91bmQnIH07XG4gIH1cblxuICAvLyBVc2UgdGhlIGV4aXN0aW5nIHVwZGF0ZV9wcm9maWxlX2Nvb3JkcyBmdW5jdGlvblxuICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UucnBjKCd1cGRhdGVfcHJvZmlsZV9jb29yZHMnLCB7XG4gICAgcF91c2VyX2lkOiB1c2VyLmlkLFxuICAgIHBfbmFtZTogcHJvZmlsZS5uYW1lLFxuICAgIHBfcm9sZTogcHJvZmlsZS5yb2xlLFxuICAgIHBfdHJhZGU6IHByb2ZpbGUudHJhZGUsXG4gICAgcF9sb2NhdGlvbjogZGF0YS5sb2NhdGlvbixcbiAgICBwX2xuZzogZGF0YS5jb29yZHMubG5nLFxuICAgIHBfbGF0OiBkYXRhLmNvb3Jkcy5sYXQsXG4gICAgcF9iaW86IHByb2ZpbGUuYmlvLFxuICAgIHBfc3ViX3RyYWRlOiBwcm9maWxlLnN1Yl90cmFkZSxcbiAgICBwX2VtcGxveWVyX3R5cGU6IHByb2ZpbGUuZW1wbG95ZXJfdHlwZSxcbiAgfSk7XG5cbiAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiB1cGRhdGVFcnJvci5tZXNzYWdlIH07XG4gIH1cblxuICByZXZhbGlkYXRlUGF0aCgnL2Rhc2hib2FyZC9mZWVkJyk7XG4gIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL3Byb2ZpbGUnKTtcbiAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiIwVEFrSXNCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/dashboard/components/initial-location-capture.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InitialLocationCapture",
    ()=>InitialLocationCapture
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$profile$2f$actions$2f$data$3a$75b39e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/features/profile/actions/data:75b39e [app-client] (ecmascript) <text/javascript>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function InitialLocationCapture() {
    _s();
    const [hasRequested, setHasRequested] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InitialLocationCapture.useEffect": ()=>{
            // Only run once
            if (hasRequested) return;
            // Check if we've already captured initial location
            const locationCaptured = localStorage.getItem('initial_location_captured');
            if (locationCaptured) return;
            // Request location permission
            if ('geolocation' in navigator) {
                setHasRequested(true);
                navigator.geolocation.getCurrentPosition({
                    "InitialLocationCapture.useEffect": async (position)=>{
                        const { latitude, longitude } = position.coords;
                        try {
                            // Update profile with location
                            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$profile$2f$actions$2f$data$3a$75b39e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["updateProfileLocation"])({
                                coords: {
                                    lat: latitude,
                                    lng: longitude
                                },
                                location: `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`
                            });
                            if (result.success) {
                                // Mark as captured so we don't ask again
                                localStorage.setItem('initial_location_captured', 'true');
                                console.log('Initial location saved successfully');
                            } else {
                                console.error('Failed to save initial location:', result.error);
                            }
                        } catch (error) {
                            console.error('Failed to save initial location:', error);
                        }
                    }
                }["InitialLocationCapture.useEffect"], {
                    "InitialLocationCapture.useEffect": (error)=>{
                        // User denied or error occurred
                        console.log('Location permission denied or error:', error);
                        // Still mark as captured so we don't keep asking
                        localStorage.setItem('initial_location_captured', 'true');
                    }
                }["InitialLocationCapture.useEffect"], {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                });
            }
        }
    }["InitialLocationCapture.useEffect"], [
        hasRequested
    ]);
    // This component doesn't render anything
    return null;
}
_s(InitialLocationCapture, "pTxGfiDQFskHw9BBF9WClybD+Gc=");
_c = InitialLocationCapture;
var _c;
__turbopack_context__.k.register(_c, "InitialLocationCapture");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=fb148e41-ad6d-2e04-fe3c-2e7397667f4f
//# sourceMappingURL=features_0422a1d8._.js.map