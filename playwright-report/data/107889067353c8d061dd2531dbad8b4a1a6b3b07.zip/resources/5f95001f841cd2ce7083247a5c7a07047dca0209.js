;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="255e76a8-d45b-2e76-af7e-76981cc2d204")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn,
    "formatDate",
    ()=>formatDate,
    "formatRelativeTime",
    ()=>formatRelativeTime,
    "sleep",
    ()=>sleep,
    "truncate",
    ()=>truncate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
function formatDate(date) {
    const d = typeof date === 'string' ? new Date(date) : date;
    return d.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
    });
}
function formatRelativeTime(date) {
    const d = typeof date === 'string' ? new Date(date) : date;
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - d.getTime()) / 1000);
    if (diffInSeconds < 60) {
        return 'just now';
    }
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) {
        return `${diffInMinutes} ${diffInMinutes === 1 ? 'minute' : 'minutes'} ago`;
    }
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
        return `${diffInHours} ${diffInHours === 1 ? 'hour' : 'hours'} ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) {
        return `${diffInDays} ${diffInDays === 1 ? 'day' : 'days'} ago`;
    }
    return formatDate(d);
}
function sleep(ms) {
    return new Promise((resolve)=>setTimeout(resolve, ms));
}
function truncate(str, length) {
    if (str.length <= length) return str;
    return str.slice(0, length) + '...';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Button = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ className, variant = 'primary', size = 'md', isLoading = false, disabled, children, ...props }, ref)=>{
    const baseStyles = 'inline-flex items-center justify-center font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 rounded-lg';
    const variants = {
        primary: 'bg-krewup-blue text-white hover:bg-blue-700 focus-visible:ring-krewup-blue',
        secondary: 'bg-krewup-orange text-white hover:bg-orange-600 focus-visible:ring-krewup-orange',
        outline: 'border-2 border-gray-300 bg-white text-gray-700 hover:bg-gray-50 focus-visible:ring-gray-400',
        ghost: 'bg-transparent text-gray-700 hover:bg-gray-100 focus-visible:ring-gray-400',
        danger: 'bg-red-600 text-white hover:bg-red-700 focus-visible:ring-red-600'
    };
    const sizes = {
        sm: 'h-8 px-3 text-sm',
        md: 'h-10 px-4 text-base',
        lg: 'h-12 px-6 text-lg'
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(baseStyles, variants[variant], sizes[size], className),
        disabled: disabled || isLoading,
        ...props,
        children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "mr-2 h-4 w-4 animate-spin",
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                            className: "opacity-25",
                            cx: "12",
                            cy: "12",
                            r: "10",
                            stroke: "currentColor",
                            strokeWidth: "4"
                        }, void 0, false, {
                            fileName: "[project]/components/ui/button.tsx",
                            lineNumber: 69,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            className: "opacity-75",
                            fill: "currentColor",
                            d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        }, void 0, false, {
                            fileName: "[project]/components/ui/button.tsx",
                            lineNumber: 77,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ui/button.tsx",
                    lineNumber: 63,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                "Loading..."
            ]
        }, void 0, true) : children
    }, void 0, false, {
        fileName: "[project]/components/ui/button.tsx",
        lineNumber: 55,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Button;
Button.displayName = 'Button';
var _c, _c1;
__turbopack_context__.k.register(_c, "Button$forwardRef");
__turbopack_context__.k.register(_c1, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Input = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ className, label, error, helperText, id, value, defaultValue, ...props }, ref)=>{
    const inputId = id || label?.toLowerCase().replace(/\s+/g, '-');
    // Prevent controlled/uncontrolled switching
    // If value is provided (even if undefined), ensure it's always a string
    const controlledProps = value !== undefined ? {
        value: value ?? ''
    } : defaultValue !== undefined ? {
        defaultValue: defaultValue ?? ''
    } : {};
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: inputId,
                className: "mb-1.5 block text-sm font-medium text-gray-700",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/ui/input.tsx",
                lineNumber: 40,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ref: ref,
                id: inputId,
                ...props,
                ...controlledProps,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex h-10 w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm', 'placeholder:text-gray-400', 'focus:outline-none focus:ring-2 focus:ring-krewup-blue focus:border-transparent', 'disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-gray-50', error && 'border-red-500 focus:ring-red-500', className)
            }, void 0, false, {
                fileName: "[project]/components/ui/input.tsx",
                lineNumber: 47,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1.5 text-sm text-red-600",
                children: error
            }, void 0, false, {
                fileName: "[project]/components/ui/input.tsx",
                lineNumber: 61,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
            helperText && !error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1.5 text-sm text-gray-500",
                children: helperText
            }, void 0, false, {
                fileName: "[project]/components/ui/input.tsx",
                lineNumber: 63,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/input.tsx",
        lineNumber: 38,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Input;
Input.displayName = 'Input';
var _c, _c1;
__turbopack_context__.k.register(_c, "Input$forwardRef");
__turbopack_context__.k.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/select.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Select",
    ()=>Select
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Select = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ className, label, error, helperText, options, id, ...props }, ref)=>{
    const selectId = id || label?.toLowerCase().replace(/\s+/g, '-');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: selectId,
                className: "mb-1.5 block text-sm font-medium text-gray-700",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/ui/select.tsx",
                lineNumber: 35,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                ref: ref,
                id: selectId,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex h-10 w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm', 'focus:outline-none focus:ring-2 focus:ring-krewup-blue focus:border-transparent', 'disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-gray-50', error && 'border-red-500 focus:ring-red-500', className),
                ...props,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        value: "",
                        disabled: true,
                        children: "Select an option"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/select.tsx",
                        lineNumber: 54,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    options.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                            value: option.value,
                            children: option.label
                        }, option.value, false, {
                            fileName: "[project]/components/ui/select.tsx",
                            lineNumber: 58,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/select.tsx",
                lineNumber: 42,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1.5 text-sm text-red-600",
                children: error
            }, void 0, false, {
                fileName: "[project]/components/ui/select.tsx",
                lineNumber: 63,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
            helperText && !error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1.5 text-sm text-gray-500",
                children: helperText
            }, void 0, false, {
                fileName: "[project]/components/ui/select.tsx",
                lineNumber: 65,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/select.tsx",
        lineNumber: 33,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Select;
Select.displayName = 'Select';
var _c, _c1;
__turbopack_context__.k.register(_c, "Select$forwardRef");
__turbopack_context__.k.register(_c1, "Select");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/textarea.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Textarea",
    ()=>Textarea
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Textarea = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ className, label, helperText, error, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "block text-sm font-medium text-gray-700 mb-1.5",
                children: [
                    label,
                    props.required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-red-500 ml-1",
                        children: "*"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/textarea.tsx",
                        lineNumber: 31,
                        columnNumber: 32
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/textarea.tsx",
                lineNumber: 29,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                ref: ref,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex min-h-[80px] w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm placeholder:text-gray-400', 'focus:outline-none focus:ring-2 focus:ring-krewup-blue focus:border-transparent', 'disabled:cursor-not-allowed disabled:opacity-50', 'resize-none', error && 'border-red-300 focus:ring-red-500', className),
                ...props
            }, void 0, false, {
                fileName: "[project]/components/ui/textarea.tsx",
                lineNumber: 34,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            helperText && !error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1.5 text-sm text-gray-500",
                children: helperText
            }, void 0, false, {
                fileName: "[project]/components/ui/textarea.tsx",
                lineNumber: 47,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1.5 text-sm text-red-600",
                children: error
            }, void 0, false, {
                fileName: "[project]/components/ui/textarea.tsx",
                lineNumber: 50,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/textarea.tsx",
        lineNumber: 27,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Textarea;
Textarea.displayName = 'Textarea';
var _c, _c1;
__turbopack_context__.k.register(_c, "Textarea$forwardRef");
__turbopack_context__.k.register(_c1, "Textarea");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/badge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Badge",
    ()=>Badge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Badge = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ className, variant = 'default', ...props }, ref)=>{
    const variants = {
        default: 'bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800 border-gray-300 shadow-sm',
        success: 'bg-gradient-to-r from-green-400 to-emerald-500 text-white border-green-500 shadow-md',
        warning: 'bg-gradient-to-r from-yellow-400 to-orange-400 text-white border-yellow-500 shadow-md',
        danger: 'bg-gradient-to-r from-red-400 to-red-600 text-white border-red-500 shadow-md',
        info: 'bg-gradient-to-r from-krewup-blue to-krewup-light-blue text-white border-blue-500 shadow-md',
        pro: 'bg-gradient-to-r from-krewup-blue to-krewup-orange text-white border-transparent shadow-lg animate-pulse'
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors', variants[variant], className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/badge.tsx",
        lineNumber: 32,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Badge;
Badge.displayName = 'Badge';
var _c, _c1;
__turbopack_context__.k.register(_c, "Badge$forwardRef");
__turbopack_context__.k.register(_c1, "Badge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ className, variant = 'default', ...props }, ref)=>{
    const variants = {
        default: 'bg-white border border-gray-200 shadow-md hover:shadow-xl transition-shadow duration-300',
        elevated: 'bg-white shadow-xl hover:shadow-2xl transition-shadow duration-300',
        outlined: 'bg-white border-2 border-krewup-light-blue shadow-lg hover:shadow-xl transition-all duration-300 hover:border-krewup-blue'
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('rounded-xl', variants[variant], className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 35,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Card;
Card.displayName = 'Card';
const CardHeader = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c2 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex flex-col space-y-1.5 p-6', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 48,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
_c3 = CardHeader;
CardHeader.displayName = 'CardHeader';
const CardTitle = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-2xl font-bold leading-none tracking-tight bg-gradient-to-r from-krewup-blue to-krewup-orange bg-clip-text text-transparent', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 56,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
_c5 = CardTitle;
CardTitle.displayName = 'CardTitle';
const CardDescription = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c6 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-sm text-gray-500', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 70,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c7 = CardDescription;
CardDescription.displayName = 'CardDescription';
const CardContent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c8 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('p-6 pt-0', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 77,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
_c9 = CardContent;
CardContent.displayName = 'CardContent';
const CardFooter = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c10 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex items-center p-6 pt-0', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 85,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
_c11 = CardFooter;
CardFooter.displayName = 'CardFooter';
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "Card$forwardRef");
__turbopack_context__.k.register(_c1, "Card");
__turbopack_context__.k.register(_c2, "CardHeader$forwardRef");
__turbopack_context__.k.register(_c3, "CardHeader");
__turbopack_context__.k.register(_c4, "CardTitle$forwardRef");
__turbopack_context__.k.register(_c5, "CardTitle");
__turbopack_context__.k.register(_c6, "CardDescription$forwardRef");
__turbopack_context__.k.register(_c7, "CardDescription");
__turbopack_context__.k.register(_c8, "CardContent$forwardRef");
__turbopack_context__.k.register(_c9, "CardContent");
__turbopack_context__.k.register(_c10, "CardFooter$forwardRef");
__turbopack_context__.k.register(_c11, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/confirm-dialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ConfirmDialog",
    ()=>ConfirmDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
'use client';
;
;
function ConfirmDialog({ isOpen, onClose, onConfirm, title, message, confirmText = 'Confirm', cancelText = 'Cancel', isLoading = false }) {
    if (!isOpen) return null;
    const handleConfirm = ()=>{
        onConfirm();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-xl shadow-2xl max-w-md w-full border-2 border-gray-200",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-6 rounded-t-xl bg-gradient-to-r from-red-500 to-red-600",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-bold text-white",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/components/ui/confirm-dialog.tsx",
                        lineNumber: 36,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/ui/confirm-dialog.tsx",
                    lineNumber: 35,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-6 space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-700 leading-relaxed",
                            children: message
                        }, void 0, false, {
                            fileName: "[project]/components/ui/confirm-dialog.tsx",
                            lineNumber: 40,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-3 pt-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: onClose,
                                    variant: "outline",
                                    disabled: isLoading,
                                    className: "flex-1",
                                    children: cancelText
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/confirm-dialog.tsx",
                                    lineNumber: 43,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: handleConfirm,
                                    variant: "danger",
                                    isLoading: isLoading,
                                    disabled: isLoading,
                                    className: "flex-1",
                                    children: confirmText
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/confirm-dialog.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ui/confirm-dialog.tsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ui/confirm-dialog.tsx",
                    lineNumber: 39,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/ui/confirm-dialog.tsx",
            lineNumber: 34,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ui/confirm-dialog.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_c = ConfirmDialog;
var _c;
__turbopack_context__.k.register(_c, "ConfirmDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/loading-spinner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InlineSpinner",
    ()=>InlineSpinner,
    "LoadingSpinner",
    ()=>LoadingSpinner,
    "PageLoadingSpinner",
    ()=>PageLoadingSpinner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
const sizeClasses = {
    sm: 'h-4 w-4 border-2',
    md: 'h-8 w-8 border-2',
    lg: 'h-12 w-12 border-3',
    xl: 'h-16 w-16 border-4'
};
function LoadingSpinner({ size = 'md', className, label }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center justify-center gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('animate-spin rounded-full border-krewup-blue border-t-transparent', sizeClasses[size], className),
                role: "status",
                "aria-label": label || 'Loading'
            }, void 0, false, {
                fileName: "[project]/components/ui/loading-spinner.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this),
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-600",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/ui/loading-spinner.tsx",
                lineNumber: 28,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/loading-spinner.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_c = LoadingSpinner;
function PageLoadingSpinner({ label }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex min-h-screen items-center justify-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LoadingSpinner, {
            size: "xl",
            label: label || 'Loading...'
        }, void 0, false, {
            fileName: "[project]/components/ui/loading-spinner.tsx",
            lineNumber: 39,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ui/loading-spinner.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
_c1 = PageLoadingSpinner;
function InlineSpinner({ className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent', className),
        role: "status",
        "aria-label": "Loading"
    }, void 0, false, {
        fileName: "[project]/components/ui/loading-spinner.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, this);
}
_c2 = InlineSpinner;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "LoadingSpinner");
__turbopack_context__.k.register(_c1, "PageLoadingSpinner");
__turbopack_context__.k.register(_c2, "InlineSpinner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/error-boundary.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ErrorBoundary",
    ()=>ErrorBoundary,
    "ErrorFallback",
    ()=>ErrorFallback
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
'use client';
;
;
;
class ErrorBoundary extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"] {
    constructor(props){
        super(props);
        this.state = {
            hasError: false,
            error: null
        };
    }
    static getDerivedStateFromError(error) {
        return {
            hasError: true,
            error
        };
    }
    componentDidCatch(error, errorInfo) {
        console.error('ErrorBoundary caught an error:', error, errorInfo);
        if (this.props.onError) {
            this.props.onError(error, errorInfo);
        }
    }
    handleReset = ()=>{
        this.setState({
            hasError: false,
            error: null
        });
    };
    render() {
        if (this.state.hasError) {
            if (this.props.fallback) {
                return this.props.fallback;
            }
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex min-h-screen items-center justify-center bg-gray-50 px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full max-w-md text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-red-100",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "h-8 w-8 text-red-600",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/error-boundary.tsx",
                                    lineNumber: 55,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/ui/error-boundary.tsx",
                                lineNumber: 49,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/ui/error-boundary.tsx",
                            lineNumber: 48,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "mb-2 text-2xl font-bold text-gray-900",
                            children: "Something went wrong"
                        }, void 0, false, {
                            fileName: "[project]/components/ui/error-boundary.tsx",
                            lineNumber: 64,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mb-6 text-sm text-gray-600",
                            children: this.state.error?.message || 'An unexpected error occurred'
                        }, void 0, false, {
                            fileName: "[project]/components/ui/error-boundary.tsx",
                            lineNumber: 68,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: this.handleReset,
                                    className: "w-full",
                                    children: "Try again"
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/error-boundary.tsx",
                                    lineNumber: 73,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    variant: "outline",
                                    onClick: ()=>window.location.href = '/dashboard/feed',
                                    className: "w-full",
                                    children: "Go to dashboard"
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/error-boundary.tsx",
                                    lineNumber: 77,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ui/error-boundary.tsx",
                            lineNumber: 72,
                            columnNumber: 13
                        }, this),
                        ("TURBOPACK compile-time value", "development") === 'development' && this.state.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                            className: "mt-6 text-left",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                    className: "cursor-pointer text-sm font-medium text-gray-700",
                                    children: "Error details (development only)"
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/error-boundary.tsx",
                                    lineNumber: 88,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                                    className: "mt-2 overflow-auto rounded-lg bg-gray-100 p-4 text-xs text-gray-800",
                                    children: this.state.error.stack
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/error-boundary.tsx",
                                    lineNumber: 91,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ui/error-boundary.tsx",
                            lineNumber: 87,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ui/error-boundary.tsx",
                    lineNumber: 47,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ui/error-boundary.tsx",
                lineNumber: 46,
                columnNumber: 9
            }, this);
        }
        return this.props.children;
    }
}
function ErrorFallback({ error, onReset }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-lg border border-red-200 bg-red-50 p-6 text-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-red-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "h-6 w-6 text-red-600",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M6 18L18 6M6 6l12 12"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/error-boundary.tsx",
                        lineNumber: 124,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/ui/error-boundary.tsx",
                    lineNumber: 118,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ui/error-boundary.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "mb-2 text-lg font-semibold text-gray-900",
                children: "Error loading content"
            }, void 0, false, {
                fileName: "[project]/components/ui/error-boundary.tsx",
                lineNumber: 133,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mb-4 text-sm text-gray-600",
                children: error.message
            }, void 0, false, {
                fileName: "[project]/components/ui/error-boundary.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this),
            onReset && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                size: "sm",
                onClick: onReset,
                children: "Try again"
            }, void 0, false, {
                fileName: "[project]/components/ui/error-boundary.tsx",
                lineNumber: 142,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/error-boundary.tsx",
        lineNumber: 116,
        columnNumber: 5
    }, this);
}
_c = ErrorFallback;
var _c;
__turbopack_context__.k.register(_c, "ErrorFallback");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/empty-state.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EmptyApplications",
    ()=>EmptyApplications,
    "EmptyCertifications",
    ()=>EmptyCertifications,
    "EmptyExperience",
    ()=>EmptyExperience,
    "EmptyJobs",
    ()=>EmptyJobs,
    "EmptyMessages",
    ()=>EmptyMessages,
    "EmptyState",
    ()=>EmptyState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
function EmptyState({ icon, title, description, action, className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex flex-col items-center justify-center py-12 px-4 text-center', className),
        children: [
            icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gray-100 text-gray-400",
                children: icon
            }, void 0, false, {
                fileName: "[project]/components/ui/empty-state.tsx",
                lineNumber: 34,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "mb-2 text-lg font-semibold text-gray-900",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/ui/empty-state.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mb-6 max-w-sm text-sm text-gray-600",
                children: description
            }, void 0, false, {
                fileName: "[project]/components/ui/empty-state.tsx",
                lineNumber: 42,
                columnNumber: 9
            }, this),
            action && (action.href ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: action.href,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    children: action.label
                }, void 0, false, {
                    fileName: "[project]/components/ui/empty-state.tsx",
                    lineNumber: 48,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ui/empty-state.tsx",
                lineNumber: 47,
                columnNumber: 11
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                onClick: action.onClick,
                children: action.label
            }, void 0, false, {
                fileName: "[project]/components/ui/empty-state.tsx",
                lineNumber: 51,
                columnNumber: 11
            }, this))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/empty-state.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_c = EmptyState;
function EmptyJobs({ userRole }) {
    const isEmployer = userRole === 'employer';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EmptyState, {
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: "h-8 w-8",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
            }, void 0, false, {
                fileName: "[project]/components/ui/empty-state.tsx",
                lineNumber: 69,
                columnNumber: 11
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/components/ui/empty-state.tsx",
            lineNumber: 68,
            columnNumber: 9
        }, void 0),
        title: isEmployer ? "No jobs posted yet" : "No jobs available",
        description: isEmployer ? "Start posting jobs to find skilled workers for your projects" : "Check back soon for new job opportunities in your area",
        action: isEmployer ? {
            label: "Post a job",
            href: "/dashboard/jobs/new"
        } : undefined
    }, void 0, false, {
        fileName: "[project]/components/ui/empty-state.tsx",
        lineNumber: 66,
        columnNumber: 5
    }, this);
}
_c1 = EmptyJobs;
function EmptyApplications({ userRole }) {
    const isEmployer = userRole === 'employer';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EmptyState, {
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: "h-8 w-8",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            }, void 0, false, {
                fileName: "[project]/components/ui/empty-state.tsx",
                lineNumber: 102,
                columnNumber: 11
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/components/ui/empty-state.tsx",
            lineNumber: 101,
            columnNumber: 9
        }, void 0),
        title: isEmployer ? "No applications yet" : "No applications submitted",
        description: isEmployer ? "Applications will appear here when workers apply to your jobs" : "Browse available jobs and apply to get started",
        action: !isEmployer ? {
            label: "Browse jobs",
            href: "/dashboard/jobs"
        } : undefined
    }, void 0, false, {
        fileName: "[project]/components/ui/empty-state.tsx",
        lineNumber: 99,
        columnNumber: 5
    }, this);
}
_c2 = EmptyApplications;
function EmptyMessages() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EmptyState, {
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: "h-8 w-8",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
            }, void 0, false, {
                fileName: "[project]/components/ui/empty-state.tsx",
                lineNumber: 133,
                columnNumber: 11
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/components/ui/empty-state.tsx",
            lineNumber: 132,
            columnNumber: 9
        }, void 0),
        title: "No messages yet",
        description: "Start a conversation by messaging someone from their profile or job posting"
    }, void 0, false, {
        fileName: "[project]/components/ui/empty-state.tsx",
        lineNumber: 130,
        columnNumber: 5
    }, this);
}
_c3 = EmptyMessages;
function EmptyCertifications() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EmptyState, {
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: "h-8 w-8",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"
            }, void 0, false, {
                fileName: "[project]/components/ui/empty-state.tsx",
                lineNumber: 152,
                columnNumber: 11
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/components/ui/empty-state.tsx",
            lineNumber: 151,
            columnNumber: 9
        }, void 0),
        title: "No certifications added",
        description: "Add your professional certifications to stand out to employers"
    }, void 0, false, {
        fileName: "[project]/components/ui/empty-state.tsx",
        lineNumber: 149,
        columnNumber: 5
    }, this);
}
_c4 = EmptyCertifications;
function EmptyExperience() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EmptyState, {
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: "h-8 w-8",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
            }, void 0, false, {
                fileName: "[project]/components/ui/empty-state.tsx",
                lineNumber: 171,
                columnNumber: 11
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/components/ui/empty-state.tsx",
            lineNumber: 170,
            columnNumber: 9
        }, void 0),
        title: "No work experience added",
        description: "Showcase your professional experience to increase your chances of getting hired"
    }, void 0, false, {
        fileName: "[project]/components/ui/empty-state.tsx",
        lineNumber: 168,
        columnNumber: 5
    }, this);
}
_c5 = EmptyExperience;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "EmptyState");
__turbopack_context__.k.register(_c1, "EmptyJobs");
__turbopack_context__.k.register(_c2, "EmptyApplications");
__turbopack_context__.k.register(_c3, "EmptyMessages");
__turbopack_context__.k.register(_c4, "EmptyCertifications");
__turbopack_context__.k.register(_c5, "EmptyExperience");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * UI Components Library
 *
 * Centralized export for all UI components.
 * Import components like: import { Button, Card } from '@/components/ui';
 */ __turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/toast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$confirm$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/confirm-dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$loading$2d$spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/loading-spinner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$error$2d$boundary$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/error-boundary.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$empty$2d$state$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/empty-state.tsx [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/constants/certifications.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Worker Certifications organized by Trades
// Data from docs/certifications-organized.md
__turbopack_context__.s([
    "ALL_CERTIFICATIONS",
    ()=>ALL_CERTIFICATIONS,
    "CERTIFICATION_CATEGORIES",
    ()=>CERTIFICATION_CATEGORIES,
    "TRADE_TO_CERT_CATEGORY",
    ()=>TRADE_TO_CERT_CATEGORY
]);
const CERTIFICATION_CATEGORIES = {
    'Electrical': [
        'General Electrician',
        'Residential Electrician',
        'Fire/Life Safety Technician',
        'Voice Data Video (VDV) Technician',
        'Non-Residential Lighting Technician',
        'DIR'
    ],
    'Plumbing': [
        'Journey-Level Plumber',
        'Registered Apprentice'
    ],
    'HVAC and Refrigeration': [
        'Universal EPA 608',
        'EPA 608 Type I',
        'EPA 608 Type II',
        'EPA 608 Type III',
        'NATE'
    ],
    'Welding': [
        'AWS',
        'LADBS Certified Welder'
    ],
    'Safety': [
        'OSHA 10',
        'OSHA 30',
        'HAZWOPER',
        'HAZWOPER 40',
        'HAZWOPER 24',
        'HAZWOPER 8 Supervisor'
    ],
    'Hazardous Materials': [
        'Lead Supervisor',
        'Lead Worker',
        'Lead Inspector/Assessor',
        'Project Monitor Compliance',
        'Sampling Technician',
        'CAC',
        'CSST',
        'DOSH/Cal-OSHA'
    ],
    'Heavy Equipment': [
        'NCCCO',
        'Forklift Operator'
    ],
    'Traffic Control': [
        'Flagger',
        'TCT'
    ],
    'Inspection & Compliance': [
        'ICC: B1/B2/B3',
        'ICC: E1/E2',
        'ICC: P1/P2',
        'ICC: M1/M2',
        'ACI',
        'CWI',
        'DSA: Class 1',
        'DSA: Class 2',
        'DSA: Class 3',
        'IOR: Class A',
        'IOR: Class B',
        'IOR: Class C',
        'CESSWI'
    ],
    'Green Energy & Efficiency': [
        'LEED Green',
        'LEED AP',
        'LEED AP: BD+C',
        'LEED AP: O+M',
        'LEED AP: ID+C',
        'WELL AP',
        'CEA',
        'HERS Rater',
        'CALGreen Inspector',
        'Title 24'
    ],
    'Management & Administration': [
        'CCM',
        'CAC',
        'CPC',
        'PMP',
        'PMI-CP',
        'CST: Level I',
        'CST: Level II',
        'CST: Level III',
        'CST: Level IV'
    ],
    'Environmental & Civil Infra': [
        'SWRCB: D1',
        'SWRCB: D2',
        'SWRCB: D3',
        'SWRCB: D4',
        'SWRCB: D5',
        'QSD',
        'QSP'
    ]
};
const ALL_CERTIFICATIONS = Object.values(CERTIFICATION_CATEGORIES).flat();
const TRADE_TO_CERT_CATEGORY = {
    'Operating Engineers': 'Heavy Equipment',
    'Demolition Specialists': 'Safety',
    'Craft Laborers': 'Safety',
    'Ironworkers': 'Welding',
    'Concrete Masons & Cement Finishers': 'Inspection & Compliance',
    'Carpenters (Rough)': 'Safety',
    'Masons': 'Inspection & Compliance',
    'Roofers': 'Safety',
    'Glaziers': 'Safety',
    'Insulation Workers': 'Hazardous Materials',
    'Electricians': 'Electrical',
    'Plumbers & Pipefitters': 'Plumbing',
    'HVAC & Sheet Metal Workers': 'HVAC and Refrigeration',
    'Drywall & Lathers': 'Safety',
    'Painters & Wall Coverers': 'Hazardous Materials',
    'Flooring Installers': 'Safety',
    'Finish Carpenters': 'Safety',
    'Millwrights': 'Heavy Equipment',
    'Elevator Constructors': 'Safety',
    'Fence Erectors': 'Safety',
    'Commercial Divers': 'Safety',
    'Green Energy Technicians': 'Green Energy & Efficiency',
    'Administration': 'Management & Administration'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/constants/licenses.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Contractor Licenses organized by category
// Data from docs/certifications-organized.md
__turbopack_context__.s([
    "ALL_LICENSES",
    ()=>ALL_LICENSES,
    "LICENSE_CATEGORIES",
    ()=>LICENSE_CATEGORIES
]);
const LICENSE_CATEGORIES = {
    'General Licenses': [
        'Class A',
        'Class B',
        'Class B-2'
    ],
    'Specialty Contractors (Class C)': [
        'C-2',
        'C-4',
        'C-5',
        'C-6',
        'C-7',
        'C-8',
        'C-9',
        'C-10',
        'C-11',
        'C-12',
        'C-13',
        'C-15',
        'C-16',
        'C-17',
        'C-20',
        'C-21',
        'C-22',
        'C-29',
        'C-35',
        'C-36',
        'C-38',
        'C-39',
        'C-46',
        'C-47',
        'C-51',
        'C-53',
        'C-54',
        'C-55',
        'C-57',
        'C-60'
    ],
    'Limited Specialty (C-61)': [
        'D-49',
        'D-50',
        'D-52',
        'D-59',
        'D-62',
        'D-63'
    ]
};
const ALL_LICENSES = Object.values(LICENSE_CATEGORIES).flat();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/constants.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// Trade categories and subcategories
__turbopack_context__.s([
    "APPLICATION_STATUSES",
    ()=>APPLICATION_STATUSES,
    "CERTIFICATIONS",
    ()=>CERTIFICATIONS,
    "EMPLOYER_TYPES",
    ()=>EMPLOYER_TYPES,
    "EMPLOYER_TYPE_LABELS",
    ()=>EMPLOYER_TYPE_LABELS,
    "JOB_STATUSES",
    ()=>JOB_STATUSES,
    "JOB_TYPES",
    ()=>JOB_TYPES,
    "NOTIFICATION_TYPES",
    ()=>NOTIFICATION_TYPES,
    "PRO_ANNUAL",
    ()=>PRO_ANNUAL,
    "PRO_MONTHLY",
    ()=>PRO_MONTHLY,
    "ROLES",
    ()=>ROLES,
    "SUBSCRIPTION_LEVELS",
    ()=>SUBSCRIPTION_LEVELS,
    "TRADES",
    ()=>TRADES,
    "TRADE_SUBCATEGORIES",
    ()=>TRADE_SUBCATEGORIES
]);
// Import new organized certifications and licenses
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2f$certifications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/constants/certifications.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2f$licenses$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/constants/licenses.ts [app-client] (ecmascript)");
const TRADES = [
    'Operating Engineers',
    'Demolition Specialists',
    'Craft Laborers',
    'Ironworkers',
    'Concrete Masons & Cement Finishers',
    'Carpenters (Rough)',
    'Masons',
    'Roofers',
    'Glaziers',
    'Insulation Workers',
    'Electricians',
    'Plumbers & Pipefitters',
    'HVAC & Sheet Metal Workers',
    'Drywall & Lathers',
    'Painters & Wall Coverers',
    'Flooring Installers',
    'Finish Carpenters',
    'Millwrights',
    'Elevator Constructors',
    'Fence Erectors',
    'Commercial Divers',
    'Green Energy Technicians',
    'Administration'
];
const TRADE_SUBCATEGORIES = {
    'Operating Engineers': [
        'Excavator Operator',
        'Bulldozer/Scraper Operator',
        'Motor Grader Operator (Blade Hand)',
        'Crane Operator (Mobile/Tower)',
        'Paving Operator'
    ],
    'Demolition Specialists': [
        'Structural Demolitionist',
        'Interior/Soft Strip Specialist',
        'Explosive Demolitionist (Blaster)'
    ],
    'Craft Laborers': [
        'Mason Tender',
        'Pipe Layer',
        'Grade Checker',
        'Traffic Control Technician (Flagger)'
    ],
    'Ironworkers': [
        'Structural Ironworker (Erector)',
        'Reinforcing Ironworker (Rod Buster)',
        'Ornamental Ironworker',
        'Rigger/Machinery Mover'
    ],
    'Concrete Masons & Cement Finishers': [
        'Flatwork Finisher',
        'Architectural/Decorative Finisher',
        'Form Setter'
    ],
    'Carpenters (Rough)': [
        'Wood Framer',
        'Metal Stud Framer',
        'Pile Driver',
        'Bridge Builder'
    ],
    'Masons': [
        'Bricklayer',
        'Stonemason',
        'Refractory Mason',
        'Restoration Mason'
    ],
    'Roofers': [
        'Low-Slope (Commercial) Roofer',
        'Steep-Slope (Residential) Roofer',
        'Waterproofer'
    ],
    'Glaziers': [
        'Curtain Wall Installer',
        'Storefront Glazier',
        'Residential Glazier'
    ],
    'Insulation Workers': [
        'Batt/Roll Installer',
        'Spray Foam Technician',
        'Firestop Containment Worker'
    ],
    'Electricians': [
        'Inside Wireman (Commercial)',
        'Residential Wireman',
        'Outside Lineman (High Voltage)',
        'Low Voltage/Limited Energy Tech (Fire Alarm, Data/Telecom, Security)'
    ],
    'Plumbers & Pipefitters': [
        'Plumber (Sanitary/Potable)',
        'Pipefitter (Industrial/Process)',
        'Steamfitter',
        'Sprinkler Fitter (Fire Suppression)'
    ],
    'HVAC & Sheet Metal Workers': [
        'HVAC Installer',
        'HVAC Service Tech',
        'Architectural Sheet Metal Worker',
        'Duct Fabricator'
    ],
    'Drywall & Lathers': [
        'Drywall Hanger',
        'Taper/Finisher',
        'Lather (Metal/Gypsum)',
        'Plasterer'
    ],
    'Painters & Wall Coverers': [
        'Commercial/Residential Painter',
        'Industrial Coating Specialist',
        'Wall Covering Installer'
    ],
    'Flooring Installers': [
        'Carpet Layer',
        'Resilient/Vinyl Layer',
        'Hardwood Finisher',
        'Terrazzo Worker',
        'Tile Setter'
    ],
    'Finish Carpenters': [
        'Trim Carpenter',
        'Cabinetmaker',
        'Millworker'
    ],
    'Millwrights': [
        'Industrial Mechanic',
        'Turbine Installer',
        'Conveyor Specialist'
    ],
    'Elevator Constructors': [
        'New Installation Mechanic',
        'Service/Repair Mechanic',
        'Modernization Specialist'
    ],
    'Fence Erectors': [
        'Chain Link',
        'Wood/Vinyl',
        'Security/Access Gate Installer'
    ],
    'Commercial Divers': [
        'Underwater Welder',
        'Marine Construction Diver',
        'Salvage Diver'
    ],
    'Green Energy Technicians': [
        'Solar PV Installer',
        'Wind Turbine Technician',
        'Weatherization Tech'
    ],
    'Administration': [
        'Project Management',
        'Quality Control',
        'Material Estimation',
        'Safety Compliance',
        'Blueprint Reading'
    ]
};
const ROLES = [
    'Worker',
    'Employer'
];
const EMPLOYER_TYPES = [
    'contractor',
    'recruiter',
    'developer'
];
const EMPLOYER_TYPE_LABELS = {
    contractor: 'Contractor',
    recruiter: 'Recruiter',
    developer: 'Developer/Home Owner'
};
const SUBSCRIPTION_LEVELS = [
    'Free',
    'Pro'
];
;
;
const CERTIFICATIONS = [
    'OSHA 10',
    'OSHA 30',
    'First Aid/CPR',
    'Forklift Operator',
    'Journeyman License',
    'Master Plumber',
    'Master Electrician',
    'Welding Certification',
    'EPA 608 Certification',
    'CDL License'
];
const PRO_MONTHLY = 15;
const PRO_ANNUAL = 150;
const JOB_TYPES = [
    'Full-Time',
    'Part-Time',
    'Contract',
    '1099',
    'Temporary'
];
const APPLICATION_STATUSES = [
    'pending',
    'viewed',
    'contacted',
    'rejected',
    'hired'
];
const JOB_STATUSES = [
    'active',
    'filled',
    'expired',
    'draft'
];
const NOTIFICATION_TYPES = [
    'new_job',
    'message',
    'application_update',
    'profile_view'
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/onboarding/actions/data:d39002 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"401d426292674bd24df8043857de588c9c03a18d3e":"completeOnboarding"},"features/onboarding/actions/onboarding-actions.ts",""] */ __turbopack_context__.s([
    "completeOnboarding",
    ()=>completeOnboarding
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var completeOnboarding = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("401d426292674bd24df8043857de588c9c03a18d3e", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "completeOnboarding"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vb25ib2FyZGluZy1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcblxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQC9saWIvc3VwYWJhc2Uvc2VydmVyJztcbmltcG9ydCB7IHJlZGlyZWN0IH0gZnJvbSAnbmV4dC9uYXZpZ2F0aW9uJztcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSAnbmV4dC9jYWNoZSc7XG5pbXBvcnQgeyBjb29raWVzIH0gZnJvbSAnbmV4dC9oZWFkZXJzJztcbmltcG9ydCB7IGFkZENlcnRpZmljYXRpb24gfSBmcm9tICdAL2ZlYXR1cmVzL3Byb2ZpbGVzL2FjdGlvbnMvY2VydGlmaWNhdGlvbi1hY3Rpb25zJztcblxuZXhwb3J0IHR5cGUgT25ib2FyZGluZ0RhdGEgPSB7XG4gIG5hbWU6IHN0cmluZztcbiAgcGhvbmU6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbiAgcm9sZTogJ3dvcmtlcicgfCAnZW1wbG95ZXInO1xuICBlbXBsb3llcl90eXBlPzogJ2NvbnRyYWN0b3InIHwgJ3JlY3J1aXRlcic7XG4gIGNvbXBhbnlfbmFtZT86IHN0cmluZzsgLy8gQnVzaW5lc3MgbmFtZSBmb3IgZW1wbG95ZXJzXG4gIHRyYWRlOiBzdHJpbmc7XG4gIHN1Yl90cmFkZT86IHN0cmluZztcbiAgbG9jYXRpb246IHN0cmluZztcbiAgY29vcmRzPzogeyBsYXQ6IG51bWJlcjsgbG5nOiBudW1iZXIgfSB8IG51bGw7XG4gIGJpbz86IHN0cmluZztcbiAgbGljZW5zZURhdGE/OiB7XG4gICAgbGljZW5zZV90eXBlOiBzdHJpbmc7XG4gICAgbGljZW5zZV9udW1iZXI6IHN0cmluZztcbiAgICBpc3N1aW5nX2F1dGhvcml0eTogc3RyaW5nO1xuICAgIGlzc3Vpbmdfc3RhdGU6IHN0cmluZztcbiAgICBpc3N1ZV9kYXRlOiBzdHJpbmc7XG4gICAgZXhwaXJlc19hdDogc3RyaW5nO1xuICAgIHBob3RvX3VybDogc3RyaW5nO1xuICB9O1xufTtcblxuZXhwb3J0IHR5cGUgT25ib2FyZGluZ1Jlc3VsdCA9IHtcbiAgc3VjY2VzczogYm9vbGVhbjtcbiAgZXJyb3I/OiBzdHJpbmc7XG59O1xuXG4vKipcbiAqIENvbXBsZXRlIHVzZXIgb25ib2FyZGluZyBhbmQgdXBkYXRlIHByb2ZpbGVcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNvbXBsZXRlT25ib2FyZGluZyhkYXRhOiBPbmJvYXJkaW5nRGF0YSk6IFByb21pc2U8T25ib2FyZGluZ1Jlc3VsdD4ge1xuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudChhd2FpdCBjb29raWVzKCkpO1xuXG4gIC8vIEdldCBjdXJyZW50IHVzZXJcbiAgY29uc3Qge1xuICAgIGRhdGE6IHsgdXNlciB9LFxuICAgIGVycm9yOiBhdXRoRXJyb3IsXG4gIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcblxuICBpZiAoYXV0aEVycm9yIHx8ICF1c2VyKSB7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnTm90IGF1dGhlbnRpY2F0ZWQnIH07XG4gIH1cblxuICAvLyBDaGVjayBpZiBwcm9maWxlIGV4aXN0c1xuICBjb25zdCB7IGRhdGE6IGV4aXN0aW5nUHJvZmlsZSwgZXJyb3I6IGNoZWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oJ3Byb2ZpbGVzJylcbiAgICAuc2VsZWN0KCdpZCcpXG4gICAgLmVxKCdpZCcsIHVzZXIuaWQpXG4gICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgY29uc29sZS5sb2coJ1tvbmJvYXJkaW5nXSBDaGVjayBleGlzdGluZyBwcm9maWxlOicsIHsgZXhpc3RzOiAhIWV4aXN0aW5nUHJvZmlsZSwgZXJyb3I6IGNoZWNrRXJyb3IgfSk7XG5cbiAgLy8gSWYgcHJvZmlsZSBkb2Vzbid0IGV4aXN0LCBjcmVhdGUgaXQgZmlyc3RcbiAgaWYgKCFleGlzdGluZ1Byb2ZpbGUpIHtcbiAgICBjb25zb2xlLmxvZygnW29uYm9hcmRpbmddIFByb2ZpbGUgZG9lcyBub3QgZXhpc3QsIGNyZWF0aW5nIGl0Li4uJyk7XG4gICAgY29uc3QgeyBlcnJvcjogaW5zZXJ0RXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgncHJvZmlsZXMnKVxuICAgICAgLmluc2VydCh7XG4gICAgICAgIGlkOiB1c2VyLmlkLFxuICAgICAgICBlbWFpbDogdXNlci5lbWFpbCB8fCBkYXRhLmVtYWlsLFxuICAgICAgICBuYW1lOiBkYXRhLm5hbWUsXG4gICAgICAgIHJvbGU6IGRhdGEucm9sZSxcbiAgICAgICAgc3Vic2NyaXB0aW9uX3N0YXR1czogJ2ZyZWUnLFxuICAgICAgICB0cmFkZTogZGF0YS50cmFkZSB8fCAnR2VuZXJhbCBMYWJvcmVyJyxcbiAgICAgICAgbG9jYXRpb246IGRhdGEubG9jYXRpb24gfHwgJ1VwZGF0ZSB5b3VyIGxvY2F0aW9uJyxcbiAgICAgICAgYmlvOiBkYXRhLmJpbyB8fCBgJHtkYXRhLnJvbGUgPT09ICd3b3JrZXInID8gJ1NraWxsZWQnIDogJ0hpcmluZyd9IHByb2Zlc3Npb25hbGAsXG4gICAgICAgIHBob25lOiBkYXRhLnBob25lLFxuICAgICAgfSk7XG5cbiAgICBpZiAoaW5zZXJ0RXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1tvbmJvYXJkaW5nXSBFcnJvciBjcmVhdGluZyBwcm9maWxlOicsIGluc2VydEVycm9yKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogYEZhaWxlZCB0byBjcmVhdGUgcHJvZmlsZTogJHtpbnNlcnRFcnJvci5tZXNzYWdlfWAgfTtcbiAgICB9XG4gICAgY29uc29sZS5sb2coJ1tvbmJvYXJkaW5nXSBQcm9maWxlIGNyZWF0ZWQgc3VjY2Vzc2Z1bGx5Jyk7XG4gIH1cblxuICAvLyBTZXQgZGVmYXVsdCBsb2NhdGlvbiBpZiBub3QgcHJvdmlkZWRcbiAgY29uc3QgbG9jYXRpb24gPSBkYXRhLmxvY2F0aW9uIHx8ICdVbml0ZWQgU3RhdGVzJztcbiAgY29uc3QgY29vcmRzID0gZGF0YS5jb29yZHM7XG5cbiAgLy8gSWYgY29vcmRzIGFyZSBwcm92aWRlZCwgdXNlIHRoZSBQb3N0Z3JlcyBmdW5jdGlvbiBmb3IgcHJvcGVyIFBvc3RHSVMgY29udmVyc2lvblxuICBpZiAoY29vcmRzICYmIHR5cGVvZiBjb29yZHMubGF0ID09PSAnbnVtYmVyJyAmJiB0eXBlb2YgY29vcmRzLmxuZyA9PT0gJ251bWJlcicpIHtcbiAgICAvLyBGaXJzdCwgdXBkYXRlIHRoZSBwcm9maWxlIHdpdGggY29vcmRzIHVzaW5nIHRoZSBSUEMgZnVuY3Rpb25cbiAgICBjb25zdCB7IGVycm9yOiBjb29yZHNFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UucnBjKCd1cGRhdGVfcHJvZmlsZV9jb29yZHMnLCB7XG4gICAgICBwX3VzZXJfaWQ6IHVzZXIuaWQsXG4gICAgICBwX25hbWU6IGRhdGEubmFtZSxcbiAgICAgIHBfcGhvbmU6IGRhdGEucGhvbmUsXG4gICAgICBwX2VtYWlsOiBkYXRhLmVtYWlsLFxuICAgICAgcF9yb2xlOiBkYXRhLnJvbGUsXG4gICAgICBwX3RyYWRlOiBkYXRhLnRyYWRlLFxuICAgICAgcF9sb2NhdGlvbjogbG9jYXRpb24sXG4gICAgICBwX2xuZzogY29vcmRzLmxuZyxcbiAgICAgIHBfbGF0OiBjb29yZHMubGF0LFxuICAgICAgcF9iaW86IGRhdGEuYmlvIHx8IGAke2RhdGEucm9sZSA9PT0gJ3dvcmtlcicgPyAnU2tpbGxlZCcgOiAnSGlyaW5nJ30gJHtkYXRhLnRyYWRlfSBwcm9mZXNzaW9uYWxgLFxuICAgICAgcF9zdWJfdHJhZGU6IGRhdGEuc3ViX3RyYWRlIHx8IG51bGwsXG4gICAgICBwX2VtcGxveWVyX3R5cGU6IGRhdGEucm9sZSA9PT0gJ2VtcGxveWVyJyA/IGRhdGEuZW1wbG95ZXJfdHlwZSB8fCBudWxsIDogbnVsbCxcbiAgICB9KTtcblxuICAgIGlmIChjb29yZHNFcnJvcikge1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBjb29yZHNFcnJvci5tZXNzYWdlIH07XG4gICAgfVxuXG4gICAgLy8gVGhlbiB1cGRhdGUgY29tcGFueV9uYW1lIHNlcGFyYXRlbHkgKG5vdCBpbiB0aGUgUlBDIGZ1bmN0aW9uKVxuICAgIGlmIChkYXRhLnJvbGUgPT09ICdlbXBsb3llcicgJiYgZGF0YS5jb21wYW55X25hbWUpIHtcbiAgICAgIGNvbnN0IHsgZXJyb3I6IGNvbXBhbnlFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oJ3Byb2ZpbGVzJylcbiAgICAgICAgLnVwZGF0ZSh7IGNvbXBhbnlfbmFtZTogZGF0YS5jb21wYW55X25hbWUgfSlcbiAgICAgICAgLmVxKCdpZCcsIHVzZXIuaWQpO1xuXG4gICAgICBpZiAoY29tcGFueUVycm9yKSB7XG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogY29tcGFueUVycm9yLm1lc3NhZ2UgfTtcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgLy8gSWYgbm8gY29vcmRzIHByb3ZpZGVkLCBkbyBhIHJlZ3VsYXIgdXBkYXRlIHdpdGhvdXQgY29vcmRzXG4gICAgY29uc3QgdXBkYXRlRGF0YTogYW55ID0ge1xuICAgICAgbmFtZTogZGF0YS5uYW1lLFxuICAgICAgcGhvbmU6IGRhdGEucGhvbmUsXG4gICAgICBlbWFpbDogZGF0YS5lbWFpbCxcbiAgICAgIHJvbGU6IGRhdGEucm9sZSxcbiAgICAgIHRyYWRlOiBkYXRhLnRyYWRlLFxuICAgICAgbG9jYXRpb246IGxvY2F0aW9uLFxuICAgICAgYmlvOiBkYXRhLmJpbyB8fCBgJHtkYXRhLnJvbGUgPT09ICd3b3JrZXInID8gJ1NraWxsZWQnIDogJ0hpcmluZyd9ICR7ZGF0YS50cmFkZX0gcHJvZmVzc2lvbmFsYCxcbiAgICB9O1xuXG4gICAgLy8gT25seSBzZXQgZW1wbG95ZXJfdHlwZSBmb3IgZW1wbG95ZXJzXG4gICAgaWYgKGRhdGEucm9sZSA9PT0gJ2VtcGxveWVyJyAmJiBkYXRhLmVtcGxveWVyX3R5cGUpIHtcbiAgICAgIHVwZGF0ZURhdGEuZW1wbG95ZXJfdHlwZSA9IGRhdGEuZW1wbG95ZXJfdHlwZTtcbiAgICB9IGVsc2Uge1xuICAgICAgdXBkYXRlRGF0YS5lbXBsb3llcl90eXBlID0gbnVsbDtcbiAgICB9XG5cbiAgICAvLyBPbmx5IHNldCBjb21wYW55X25hbWUgZm9yIGVtcGxveWVyc1xuICAgIGlmIChkYXRhLnJvbGUgPT09ICdlbXBsb3llcicgJiYgZGF0YS5jb21wYW55X25hbWUpIHtcbiAgICAgIHVwZGF0ZURhdGEuY29tcGFueV9uYW1lID0gZGF0YS5jb21wYW55X25hbWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIHVwZGF0ZURhdGEuY29tcGFueV9uYW1lID0gbnVsbDtcbiAgICB9XG5cbiAgICAvLyBPbmx5IHNldCBzdWJfdHJhZGUgaWYgcHJvdmlkZWRcbiAgICBpZiAoZGF0YS5zdWJfdHJhZGUpIHtcbiAgICAgIHVwZGF0ZURhdGEuc3ViX3RyYWRlID0gZGF0YS5zdWJfdHJhZGU7XG4gICAgfVxuXG4gICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgncHJvZmlsZXMnKVxuICAgICAgLnVwZGF0ZSh1cGRhdGVEYXRhKVxuICAgICAgLmVxKCdpZCcsIHVzZXIuaWQpO1xuXG4gICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IHVwZGF0ZUVycm9yLm1lc3NhZ2UgfTtcbiAgICB9XG4gIH1cblxuICAvLyBJZiBjb250cmFjdG9yLCBjcmVhdGUgbGljZW5zZSBjZXJ0aWZpY2F0aW9uIGFuZCBzZXQgY2FuX3Bvc3Rfam9icyB0byBmYWxzZVxuICBpZiAoZGF0YS5lbXBsb3llcl90eXBlID09PSAnY29udHJhY3RvcicgJiYgZGF0YS5saWNlbnNlRGF0YSkge1xuICAgIC8vIFNhdmUgbGljZW5zZSBhcyBjZXJ0aWZpY2F0aW9uXG4gICAgY29uc3QgY2VydFJlc3VsdCA9IGF3YWl0IGFkZENlcnRpZmljYXRpb24oe1xuICAgICAgY3JlZGVudGlhbF9jYXRlZ29yeTogJ2xpY2Vuc2UnLFxuICAgICAgY2VydGlmaWNhdGlvbl90eXBlOiBkYXRhLmxpY2Vuc2VEYXRhLmxpY2Vuc2VfdHlwZSxcbiAgICAgIGNlcnRpZmljYXRpb25fbnVtYmVyOiBkYXRhLmxpY2Vuc2VEYXRhLmxpY2Vuc2VfbnVtYmVyLFxuICAgICAgaXNzdWVkX2J5OiBkYXRhLmxpY2Vuc2VEYXRhLmlzc3VpbmdfYXV0aG9yaXR5LFxuICAgICAgaXNzdWluZ19zdGF0ZTogZGF0YS5saWNlbnNlRGF0YS5pc3N1aW5nX3N0YXRlLFxuICAgICAgaXNzdWVfZGF0ZTogZGF0YS5saWNlbnNlRGF0YS5pc3N1ZV9kYXRlLFxuICAgICAgZXhwaXJlc19hdDogZGF0YS5saWNlbnNlRGF0YS5leHBpcmVzX2F0LFxuICAgICAgcGhvdG9fdXJsOiBkYXRhLmxpY2Vuc2VEYXRhLnBob3RvX3VybCxcbiAgICB9KTtcblxuICAgIGlmICghY2VydFJlc3VsdC5zdWNjZXNzKSB7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGNlcnRSZXN1bHQuZXJyb3IgfHwgJ0ZhaWxlZCB0byBzYXZlIGxpY2Vuc2UnIH07XG4gICAgfVxuXG4gICAgLy8gU2V0IGNhbl9wb3N0X2pvYnMgdG8gZmFsc2UgdW50aWwgbGljZW5zZSB2ZXJpZmllZFxuICAgIGNvbnN0IHsgZXJyb3I6IHBvc3RKb2JzRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgncHJvZmlsZXMnKVxuICAgICAgLnVwZGF0ZSh7IGNhbl9wb3N0X2pvYnM6IGZhbHNlIH0pXG4gICAgICAuZXEoJ2lkJywgdXNlci5pZCk7XG5cbiAgICBpZiAocG9zdEpvYnNFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignW29uYm9hcmRpbmddIEVycm9yIHNldHRpbmcgY2FuX3Bvc3Rfam9iczonLCBwb3N0Sm9ic0Vycm9yKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0ZhaWxlZCB0byB1cGRhdGUgam9iIHBvc3RpbmcgcGVybWlzc2lvbnMnIH07XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coJ1tvbmJvYXJkaW5nXSBDb250cmFjdG9yIGxpY2Vuc2Ugc2F2ZWQsIGNhbl9wb3N0X2pvYnMgc2V0IHRvIGZhbHNlJyk7XG4gIH1cblxuICAvLyBWZXJpZnkgdGhlIHByb2ZpbGUgd2FzIHVwZGF0ZWQgY29ycmVjdGx5XG4gIGNvbnN0IHsgZGF0YTogdXBkYXRlZFByb2ZpbGUsIGVycm9yOiB2ZXJpZnlFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAuZnJvbSgncHJvZmlsZXMnKVxuICAgIC5zZWxlY3QoJ25hbWUsIHJvbGUsIHRyYWRlLCBsb2NhdGlvbiwgcGhvbmUsIGVtYWlsJylcbiAgICAuZXEoJ2lkJywgdXNlci5pZClcbiAgICAuc2luZ2xlKCk7XG5cbiAgY29uc29sZS5sb2coJ1tvbmJvYXJkaW5nLWFjdGlvbnNdIFByb2ZpbGUgdXBkYXRlZCBzdWNjZXNzZnVsbHknKTtcbiAgY29uc29sZS5sb2coJ1tvbmJvYXJkaW5nLWFjdGlvbnNdIFVzZXIgSUQ6JywgdXNlci5pZCk7XG4gIGNvbnNvbGUubG9nKCdbb25ib2FyZGluZy1hY3Rpb25zXSBWZXJpZnkgZXJyb3I6JywgdmVyaWZ5RXJyb3IpO1xuICBjb25zb2xlLmxvZygnW29uYm9hcmRpbmctYWN0aW9uc10gVXBkYXRlZCBwcm9maWxlIGRhdGE6JywgdXBkYXRlZFByb2ZpbGUpO1xuICBjb25zb2xlLmxvZygnW29uYm9hcmRpbmctYWN0aW9uc10gQ2hlY2tpbmcgb25ib2FyZGluZyBjb21wbGV0aW9uOicpO1xuICBjb25zb2xlLmxvZygnICAtIE5hbWUgc3RhcnRzIHdpdGggVXNlci0/OicsIHVwZGF0ZWRQcm9maWxlPy5uYW1lPy5zdGFydHNXaXRoKCdVc2VyLScpKTtcbiAgY29uc29sZS5sb2coJyAgLSBMb2NhdGlvbiBpcyBcIlVwZGF0ZSB5b3VyIGxvY2F0aW9uXCI/OicsIHVwZGF0ZWRQcm9maWxlPy5sb2NhdGlvbiA9PT0gJ1VwZGF0ZSB5b3VyIGxvY2F0aW9uJyk7XG4gIGNvbnNvbGUubG9nKCcgIC0gVHJhZGUgaXMgXCJHZW5lcmFsIExhYm9yZXJcIj86JywgdXBkYXRlZFByb2ZpbGU/LnRyYWRlID09PSAnR2VuZXJhbCBMYWJvcmVyJyk7XG5cbiAgcmV2YWxpZGF0ZVBhdGgoJy8nLCAnbGF5b3V0Jyk7XG4gIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiNlRBdUNzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/profiles/actions/data:0a6253 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"40faf7478af0a74ad7d849c1e648c670d91be02d72":"uploadCertificationPhoto"},"features/profiles/actions/certification-actions.ts",""] */ __turbopack_context__.s([
    "uploadCertificationPhoto",
    ()=>uploadCertificationPhoto
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var uploadCertificationPhoto = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40faf7478af0a74ad7d849c1e648c670d91be02d72", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "uploadCertificationPhoto"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vY2VydGlmaWNhdGlvbi1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcblxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQC9saWIvc3VwYWJhc2Uvc2VydmVyJztcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSAnbmV4dC9jYWNoZSc7XG5pbXBvcnQgeyBjb29raWVzIH0gZnJvbSAnbmV4dC9oZWFkZXJzJztcblxuZXhwb3J0IHR5cGUgQ2VydGlmaWNhdGlvbkRhdGEgPSB7XG4gIGNyZWRlbnRpYWxfY2F0ZWdvcnk6ICdsaWNlbnNlJyB8ICdjZXJ0aWZpY2F0aW9uJztcbiAgY2VydGlmaWNhdGlvbl90eXBlOiBzdHJpbmc7XG4gIGNlcnRpZmljYXRpb25fbnVtYmVyPzogc3RyaW5nO1xuICBpc3N1ZWRfYnk/OiBzdHJpbmc7XG4gIGlzc3Vpbmdfc3RhdGU/OiBzdHJpbmc7XG4gIGlzc3VlX2RhdGU/OiBzdHJpbmc7XG4gIGV4cGlyZXNfYXQ/OiBzdHJpbmc7XG4gIHBob3RvX3VybD86IHN0cmluZztcbn07XG5cbmV4cG9ydCB0eXBlIENlcnRpZmljYXRpb25SZXN1bHQgPSB7XG4gIHN1Y2Nlc3M6IGJvb2xlYW47XG4gIGRhdGE/OiBhbnk7XG4gIGVycm9yPzogc3RyaW5nO1xufTtcblxuLyoqXG4gKiBBZGQgYSBuZXcgY2VydGlmaWNhdGlvblxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkQ2VydGlmaWNhdGlvbihkYXRhOiBDZXJ0aWZpY2F0aW9uRGF0YSk6IFByb21pc2U8Q2VydGlmaWNhdGlvblJlc3VsdD4ge1xuICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudChhd2FpdCBjb29raWVzKCkpO1xuXG4gIGNvbnN0IHtcbiAgICBkYXRhOiB7IHVzZXIgfSxcbiAgICBlcnJvcjogYXV0aEVycm9yLFxuICB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKCk7XG5cbiAgaWYgKGF1dGhFcnJvciB8fCAhdXNlcikge1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ05vdCBhdXRoZW50aWNhdGVkJyB9O1xuICB9XG5cbiAgLy8gR2V0IHVzZXIncyBwcm9maWxlIHRvIGRldGVybWluZSByb2xlIGFuZCBlbXBsb3llcl90eXBlXG4gIGNvbnN0IHsgZGF0YTogcHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAuZnJvbSgncHJvZmlsZXMnKVxuICAgIC5zZWxlY3QoJ3JvbGUsIGVtcGxveWVyX3R5cGUnKVxuICAgIC5lcSgnaWQnLCB1c2VyLmlkKVxuICAgIC5zaW5nbGUoKTtcblxuICBpZiAoIXByb2ZpbGUpIHtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdQcm9maWxlIG5vdCBmb3VuZCcgfTtcbiAgfVxuXG4gIC8vIFZhbGlkYXRlIGNyZWRlbnRpYWxfY2F0ZWdvcnkgbWF0Y2hlcyB1c2VyIHJvbGVcbiAgaWYgKHByb2ZpbGUucm9sZSA9PT0gJ3dvcmtlcicgJiYgZGF0YS5jcmVkZW50aWFsX2NhdGVnb3J5ICE9PSAnY2VydGlmaWNhdGlvbicpIHtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdXb3JrZXJzIGNhbiBvbmx5IGFkZCBjZXJ0aWZpY2F0aW9ucycgfTtcbiAgfVxuXG4gIGlmIChwcm9maWxlLnJvbGUgPT09ICdlbXBsb3llcicgJiYgcHJvZmlsZS5lbXBsb3llcl90eXBlID09PSAnY29udHJhY3RvcidcbiAgICAgICYmIGRhdGEuY3JlZGVudGlhbF9jYXRlZ29yeSAhPT0gJ2xpY2Vuc2UnKSB7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnQ29udHJhY3RvcnMgY2FuIG9ubHkgYWRkIGxpY2Vuc2VzJyB9O1xuICB9XG5cbiAgaWYgKHByb2ZpbGUucm9sZSA9PT0gJ2VtcGxveWVyJyAmJiBwcm9maWxlLmVtcGxveWVyX3R5cGUgPT09ICdyZWNydWl0ZXInKSB7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnUmVjcnVpdGVycyBjYW5ub3QgYWRkIGNyZWRlbnRpYWxzJyB9O1xuICB9XG5cbiAgLy8gVmFsaWRhdGUgcmVxdWlyZWQgZmllbGRzXG4gIGlmICghZGF0YS5jZXJ0aWZpY2F0aW9uX3R5cGUgfHwgZGF0YS5jZXJ0aWZpY2F0aW9uX3R5cGUudHJpbSgpLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0NlcnRpZmljYXRpb24gdHlwZSBpcyByZXF1aXJlZCcgfTtcbiAgfVxuXG4gIC8vIEluc2VydCBjZXJ0aWZpY2F0aW9uIHdpdGggY3JlZGVudGlhbF9jYXRlZ29yeVxuICBjb25zdCB7IGRhdGE6IGNlcnRpZmljYXRpb24sIGVycm9yOiBpbnNlcnRFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAuZnJvbSgnY2VydGlmaWNhdGlvbnMnKVxuICAgIC5pbnNlcnQoe1xuICAgICAgdXNlcl9pZDogdXNlci5pZCxcbiAgICAgIGNyZWRlbnRpYWxfY2F0ZWdvcnk6IGRhdGEuY3JlZGVudGlhbF9jYXRlZ29yeSxcbiAgICAgIGNlcnRpZmljYXRpb25fdHlwZTogZGF0YS5jZXJ0aWZpY2F0aW9uX3R5cGUudHJpbSgpLFxuICAgICAgY2VydGlmaWNhdGlvbl9udW1iZXI6IGRhdGEuY2VydGlmaWNhdGlvbl9udW1iZXI/LnRyaW0oKSB8fCBudWxsLFxuICAgICAgaXNzdWVkX2J5OiBkYXRhLmlzc3VlZF9ieT8udHJpbSgpIHx8IG51bGwsXG4gICAgICBpc3N1aW5nX3N0YXRlOiBkYXRhLmlzc3Vpbmdfc3RhdGU/LnRyaW0oKSB8fCBudWxsLFxuICAgICAgaXNzdWVfZGF0ZTogZGF0YS5pc3N1ZV9kYXRlIHx8IG51bGwsXG4gICAgICBleHBpcmVzX2F0OiBkYXRhLmV4cGlyZXNfYXQgfHwgbnVsbCxcbiAgICAgIGltYWdlX3VybDogZGF0YS5waG90b191cmwgfHwgbnVsbCxcbiAgICAgIHZlcmlmaWNhdGlvbl9zdGF0dXM6ICdwZW5kaW5nJywgLy8gU3RhcnRzIGFzIHBlbmRpbmcgdmVyaWZpY2F0aW9uXG4gICAgfSlcbiAgICAuc2VsZWN0KClcbiAgICAuc2luZ2xlKCk7XG5cbiAgaWYgKGluc2VydEVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignQWRkIGNlcnRpZmljYXRpb24gZXJyb3I6JywgaW5zZXJ0RXJyb3IpO1xuICAgIC8vIFByb3ZpZGUgbW9yZSBkZXRhaWxlZCBlcnJvciBtZXNzYWdlc1xuICAgIGxldCBlcnJvck1lc3NhZ2UgPSAnRmFpbGVkIHRvIGFkZCBjZXJ0aWZpY2F0aW9uJztcbiAgICBpZiAoaW5zZXJ0RXJyb3IuY29kZSA9PT0gJzIzNTA1Jykge1xuICAgICAgZXJyb3JNZXNzYWdlID0gJ1RoaXMgY2VydGlmaWNhdGlvbiBhbHJlYWR5IGV4aXN0cyBpbiB5b3VyIHByb2ZpbGUnO1xuICAgIH0gZWxzZSBpZiAoaW5zZXJ0RXJyb3IubWVzc2FnZSkge1xuICAgICAgZXJyb3JNZXNzYWdlID0gYEZhaWxlZCB0byBhZGQgY2VydGlmaWNhdGlvbjogJHtpbnNlcnRFcnJvci5tZXNzYWdlfWA7XG4gICAgfVxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3JNZXNzYWdlIH07XG4gIH1cblxuICByZXZhbGlkYXRlUGF0aCgnL2Rhc2hib2FyZC9wcm9maWxlJyk7XG5cbiAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZGF0YTogY2VydGlmaWNhdGlvbiB9O1xufVxuXG4vKipcbiAqIERlbGV0ZSBhIGNlcnRpZmljYXRpb25cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZUNlcnRpZmljYXRpb24oY2VydGlmaWNhdGlvbklkOiBzdHJpbmcpOiBQcm9taXNlPENlcnRpZmljYXRpb25SZXN1bHQ+IHtcbiAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoYXdhaXQgY29va2llcygpKTtcblxuICBjb25zdCB7XG4gICAgZGF0YTogeyB1c2VyIH0sXG4gIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcblxuICBpZiAoIXVzZXIpIHtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdOb3QgYXV0aGVudGljYXRlZCcgfTtcbiAgfVxuXG4gIC8vIERlbGV0ZSBvbmx5IGlmIG93bmVkIGJ5IHVzZXJcbiAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAuZnJvbSgnY2VydGlmaWNhdGlvbnMnKVxuICAgIC5kZWxldGUoKVxuICAgIC5lcSgnaWQnLCBjZXJ0aWZpY2F0aW9uSWQpXG4gICAgLmVxKCd1c2VyX2lkJywgdXNlci5pZCk7XG5cbiAgaWYgKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignRGVsZXRlIGNlcnRpZmljYXRpb24gZXJyb3I6JywgZXJyb3IpO1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0ZhaWxlZCB0byBkZWxldGUgY2VydGlmaWNhdGlvbicgfTtcbiAgfVxuXG4gIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL3Byb2ZpbGUnKTtcblxuICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG59XG5cbi8qKlxuICogVXBsb2FkIGNlcnRpZmljYXRpb24gcGhvdG8gdG8gU3VwYWJhc2UgU3RvcmFnZVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBsb2FkQ2VydGlmaWNhdGlvblBob3RvKGZpbGU6IEZpbGUpOiBQcm9taXNlPENlcnRpZmljYXRpb25SZXN1bHQ+IHtcbiAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoYXdhaXQgY29va2llcygpKTtcblxuICBjb25zdCB7XG4gICAgZGF0YTogeyB1c2VyIH0sXG4gIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcblxuICBpZiAoIXVzZXIpIHtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdOb3QgYXV0aGVudGljYXRlZCcgfTtcbiAgfVxuXG4gIC8vIFZhbGlkYXRlIGZpbGUgdHlwZVxuICBjb25zdCBhbGxvd2VkVHlwZXMgPSBbJ2ltYWdlL2pwZWcnLCAnaW1hZ2UvanBnJywgJ2ltYWdlL3BuZycsICdpbWFnZS93ZWJwJywgJ2FwcGxpY2F0aW9uL3BkZiddO1xuICBpZiAoIWFsbG93ZWRUeXBlcy5pbmNsdWRlcyhmaWxlLnR5cGUpKSB7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnT25seSBpbWFnZXMgKEpQRUcsIFBORywgV2ViUCkgYW5kIFBERiBmaWxlcyBhcmUgYWxsb3dlZCcgfTtcbiAgfVxuXG4gIC8vIFZhbGlkYXRlIGZpbGUgc2l6ZSAobWF4IDVNQilcbiAgY29uc3QgbWF4U2l6ZSA9IDUgKiAxMDI0ICogMTAyNDsgLy8gNU1CXG4gIGlmIChmaWxlLnNpemUgPiBtYXhTaXplKSB7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnRmlsZSBzaXplIG11c3QgYmUgbGVzcyB0aGFuIDVNQicgfTtcbiAgfVxuXG4gIC8vIEdlbmVyYXRlIHVuaXF1ZSBmaWxlbmFtZVxuICBjb25zdCBmaWxlRXh0ID0gZmlsZS5uYW1lLnNwbGl0KCcuJykucG9wKCk7XG4gIGNvbnN0IGZpbGVOYW1lID0gYCR7dXNlci5pZH0vJHtEYXRlLm5vdygpfS4ke2ZpbGVFeHR9YDtcblxuICAvLyBVcGxvYWQgdG8gU3VwYWJhc2UgU3RvcmFnZVxuICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlXG4gICAgLmZyb20oJ2NlcnRpZmljYXRpb24tcGhvdG9zJylcbiAgICAudXBsb2FkKGZpbGVOYW1lLCBmaWxlLCB7XG4gICAgICBjYWNoZUNvbnRyb2w6ICczNjAwJyxcbiAgICAgIHVwc2VydDogZmFsc2UsXG4gICAgfSk7XG5cbiAgaWYgKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignVXBsb2FkIGNlcnRpZmljYXRpb24gcGhvdG8gZXJyb3I6JywgZXJyb3IpO1xuICAgIC8vIFByb3ZpZGUgbW9yZSBkZXRhaWxlZCBlcnJvciBtZXNzYWdlc1xuICAgIGxldCBlcnJvck1lc3NhZ2UgPSAnRmFpbGVkIHRvIHVwbG9hZCBwaG90byc7XG4gICAgaWYgKGVycm9yLm1lc3NhZ2UuaW5jbHVkZXMoJ2J1Y2tldCcpKSB7XG4gICAgICBlcnJvck1lc3NhZ2UgPSAnVXBsb2FkIHN0b3JhZ2Ugbm90IGNvbmZpZ3VyZWQuIFBsZWFzZSBjb250YWN0IHN1cHBvcnQuJztcbiAgICB9IGVsc2UgaWYgKGVycm9yLm1lc3NhZ2UpIHtcbiAgICAgIGVycm9yTWVzc2FnZSA9IGBGYWlsZWQgdG8gdXBsb2FkIHBob3RvOiAke2Vycm9yLm1lc3NhZ2V9YDtcbiAgICB9XG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBlcnJvck1lc3NhZ2UgfTtcbiAgfVxuXG4gIC8vIEdldCBwdWJsaWMgVVJMXG4gIGNvbnN0IHsgZGF0YTogdXJsRGF0YSB9ID0gc3VwYWJhc2Uuc3RvcmFnZVxuICAgIC5mcm9tKCdjZXJ0aWZpY2F0aW9uLXBob3RvcycpXG4gICAgLmdldFB1YmxpY1VybChmaWxlTmFtZSk7XG5cbiAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZGF0YTogeyB1cmw6IHVybERhdGEucHVibGljVXJsLCBwYXRoOiBmaWxlTmFtZSB9IH07XG59XG5cbi8qKlxuICogR2V0IHVzZXIncyBjZXJ0aWZpY2F0aW9uc1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TXlDZXJ0aWZpY2F0aW9ucygpOiBQcm9taXNlPENlcnRpZmljYXRpb25SZXN1bHQ+IHtcbiAgY29uc3Qgc3VwYWJhc2UgPSBhd2FpdCBjcmVhdGVDbGllbnQoYXdhaXQgY29va2llcygpKTtcblxuICBjb25zdCB7XG4gICAgZGF0YTogeyB1c2VyIH0sXG4gIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcblxuICBpZiAoIXVzZXIpIHtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdOb3QgYXV0aGVudGljYXRlZCcgfTtcbiAgfVxuXG4gIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oJ2NlcnRpZmljYXRpb25zJylcbiAgICAuc2VsZWN0KCcqJylcbiAgICAuZXEoJ3VzZXJfaWQnLCB1c2VyLmlkKVxuICAgIC5vcmRlcignY3JlYXRlZF9hdCcsIHsgYXNjZW5kaW5nOiBmYWxzZSB9KTtcblxuICBpZiAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCdHZXQgY2VydGlmaWNhdGlvbnMgZXJyb3I6JywgZXJyb3IpO1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0ZhaWxlZCB0byBnZXQgY2VydGlmaWNhdGlvbnMnIH07XG4gIH1cblxuICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBkYXRhIH07XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Im9VQXlJc0IifQ==
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/features/onboarding/components/onboarding-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OnboardingForm",
    ()=>OnboardingForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ui/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/constants.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$onboarding$2f$actions$2f$data$3a$d39002__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/features/onboarding/actions/data:d39002 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$profiles$2f$actions$2f$data$3a$0a6253__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/features/profiles/actions/data:0a6253 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function OnboardingForm({ initialName = '', initialEmail = '' }) {
    _s();
    const [step, setStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [locationStatus, setLocationStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: initialName,
        role: 'worker',
        trade: '',
        location: '',
        phone: '',
        email: initialEmail
    });
    // License state for contractors
    const [licenseFile, setLicenseFile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [licensePreview, setLicensePreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isUploadingLicense, setIsUploadingLicense] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [licenseData, setLicenseData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        license_type: '',
        license_number: '',
        issuing_authority: '',
        issuing_state: '',
        issue_date: '',
        expires_at: ''
    });
    // Capture device location on component mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OnboardingForm.useEffect": ()=>{
            captureLocation();
        }
    }["OnboardingForm.useEffect"], []);
    async function captureLocation() {
        setLocationStatus('loading');
        if (!navigator.geolocation) {
            console.warn('[captureLocation] Geolocation not supported by browser');
            setLocationStatus('error');
            return;
        }
        console.log('[captureLocation] Requesting high-accuracy GPS location...');
        navigator.geolocation.getCurrentPosition(async (position)=>{
            const { latitude, longitude, accuracy } = position.coords;
            console.log('[captureLocation] GPS success!', {
                lat: latitude,
                lng: longitude,
                accuracy: `${accuracy}m`
            });
            try {
                // Reverse geocode to get address
                const address = await reverseGeocode(latitude, longitude);
                updateFormData({
                    location: address,
                    coords: {
                        lat: latitude,
                        lng: longitude
                    }
                });
                setLocationStatus('success');
            } catch (err) {
                console.error('[captureLocation] Reverse geocoding failed:', err);
                // Still save coords even if reverse geocoding fails
                updateFormData({
                    location: `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`,
                    coords: {
                        lat: latitude,
                        lng: longitude
                    }
                });
                setLocationStatus('success');
            }
        }, (error)=>{
            console.error('[captureLocation] Geolocation error:', {
                code: error.code,
                message: error.message,
                PERMISSION_DENIED: error.code === 1,
                POSITION_UNAVAILABLE: error.code === 2,
                TIMEOUT: error.code === 3
            });
            // Don't use fallback - let user know location is required
            setLocationStatus('error');
            if (error.code === 1) {
                // Permission denied - could ask user to enable
                console.warn('[captureLocation] User denied location permission');
            } else if (error.code === 3) {
                // Timeout - GPS took too long
                console.warn('[captureLocation] GPS timeout - try again or check device settings');
            }
        }, {
            enableHighAccuracy: true,
            timeout: 30000,
            maximumAge: 0 // Don't use cached location
        });
    }
    async function reverseGeocode(lat, lng) {
        const apiKey = ("TURBOPACK compile-time value", "AIzaSyCf-5OGmOvKysJDUwrZ6XCXOVk-vk8v8ug");
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`;
        console.log('[reverseGeocode] Requesting:', url.replace(apiKey, 'API_KEY_HIDDEN'));
        const response = await fetch(url);
        if (!response.ok) {
            console.error('[reverseGeocode] HTTP error:', response.status, response.statusText);
            throw new Error(`Geocoding request failed: ${response.status}`);
        }
        const data = await response.json();
        console.log('[reverseGeocode] API response:', {
            status: data.status,
            resultsCount: data.results?.length || 0,
            errorMessage: data.error_message
        });
        if (data.status !== 'OK') {
            // Handle specific API error statuses
            if (data.status === 'REQUEST_DENIED') {
                throw new Error(`API access denied: ${data.error_message || 'Check API key and enabled APIs'}`);
            } else if (data.status === 'ZERO_RESULTS') {
                throw new Error('No address found for these coordinates');
            } else if (data.status === 'OVER_QUERY_LIMIT') {
                throw new Error('API quota exceeded');
            } else {
                throw new Error(`Geocoding failed: ${data.status} - ${data.error_message || 'Unknown error'}`);
            }
        }
        if (!data.results || data.results.length === 0) {
            throw new Error('No address found');
        }
        // Return the formatted address
        const address = data.results[0].formatted_address;
        console.log('[reverseGeocode] Success! Address:', address);
        return address;
    }
    function updateFormData(updates) {
        setFormData((prev)=>({
                ...prev,
                ...updates
            }));
    }
    function formatPhoneNumber(value) {
        // Remove all non-numeric characters
        const phoneNumber = value.replace(/\D/g, '');
        // Limit to 10 digits
        const limited = phoneNumber.slice(0, 10);
        // Format as (XXX)XXX-XXXX
        if (limited.length === 0) {
            return '';
        } else if (limited.length <= 3) {
            return `(${limited}`;
        } else if (limited.length <= 6) {
            return `(${limited.slice(0, 3)})${limited.slice(3)}`;
        } else {
            return `(${limited.slice(0, 3)})${limited.slice(3, 6)}-${limited.slice(6)}`;
        }
    }
    function handlePhoneChange(e) {
        const formatted = formatPhoneNumber(e.target.value);
        updateFormData({
            phone: formatted
        });
    }
    async function handleSubmit() {
        setError('');
        setIsLoading(true);
        try {
            // If contractor, upload license first
            let licensePhotoUrl = null;
            if (formData.employer_type === 'contractor' && licenseFile) {
                setIsUploadingLicense(true);
                // Use existing uploadCertificationPhoto action
                const uploadResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$profiles$2f$actions$2f$data$3a$0a6253__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["uploadCertificationPhoto"])(licenseFile);
                setIsUploadingLicense(false);
                if (!uploadResult.success) {
                    const errorMsg = uploadResult.error || 'Failed to upload license photo';
                    setError(errorMsg);
                    setIsLoading(false);
                    return;
                }
                licensePhotoUrl = uploadResult.data.url;
            }
            // Complete onboarding with license data
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$onboarding$2f$actions$2f$data$3a$d39002__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["completeOnboarding"])({
                ...formData,
                licenseData: formData.employer_type === 'contractor' && licensePhotoUrl ? {
                    ...licenseData,
                    photo_url: licensePhotoUrl
                } : undefined
            });
            if (!result.success) {
                setError(result.error || 'Failed to complete onboarding');
                setIsLoading(false);
                return;
            }
            // Success! Redirect to dashboard
            window.location.href = '/dashboard/feed';
        } catch (err) {
            setError(err.message || 'An unexpected error occurred');
            setIsLoading(false);
        }
    }
    // Step 1: Name, Phone, Email
    if (step === 1) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
            className: "w-full max-w-md shadow-2xl border-2 border-krewup-light-blue",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "p-6 space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-krewup-blue to-krewup-orange shadow-lg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-3xl",
                                    children: "👋"
                                }, void 0, false, {
                                    fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                    lineNumber: 248,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 247,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold bg-gradient-to-r from-krewup-blue to-krewup-orange bg-clip-text text-transparent",
                                children: "Welcome to KrewUp!"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 250,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-sm text-gray-600",
                                children: "Let's set up your profile"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 251,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                        lineNumber: 246,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: [
                            locationStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `flex items-center justify-between gap-2 rounded-lg p-3 text-sm ${locationStatus === 'loading' ? 'bg-blue-50 text-blue-700' : locationStatus === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            locationStatus === 'loading' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "h-4 w-4 animate-spin rounded-full border-2 border-blue-700 border-t-transparent"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 265,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Capturing your location... (this may take up to 30 seconds)"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 266,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true),
                                            locationStatus === 'success' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "📍"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 271,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: [
                                                            "Location captured: ",
                                                            formData.location || 'Processing...'
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 272,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true),
                                            locationStatus === 'error' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "❌"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 277,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Location access failed. Please enable location permissions and try again."
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 278,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 262,
                                        columnNumber: 17
                                    }, this),
                                    locationStatus === 'error' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: captureLocation,
                                        className: "px-3 py-1 text-xs font-medium text-red-700 hover:bg-red-100 rounded border border-red-300",
                                        children: "Retry"
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 283,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 257,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                label: "Full Name",
                                type: "text",
                                placeholder: "John Doe",
                                value: formData.name,
                                onChange: (e)=>updateFormData({
                                        name: e.target.value
                                    }),
                                required: true
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 294,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                label: "Phone Number",
                                type: "tel",
                                placeholder: "(555) 123-4567",
                                value: formData.phone,
                                onChange: handlePhoneChange,
                                required: true
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 303,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                label: "Email",
                                type: "email",
                                placeholder: "john@example.com",
                                value: formData.email,
                                onChange: (e)=>updateFormData({
                                        email: e.target.value
                                    }),
                                required: true
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 312,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                className: "w-full",
                                onClick: ()=>setStep(2),
                                disabled: !formData.name || !formData.phone || !formData.email || formData.name.length < 2,
                                children: "Continue"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 321,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                        lineNumber: 254,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-krewup-blue"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 331,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-gray-300"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 332,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-gray-300"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 333,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                        lineNumber: 330,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                lineNumber: 245,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
            lineNumber: 244,
            columnNumber: 7
        }, this);
    }
    // Step 2: Role Selection
    if (step === 2) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
            className: "w-full max-w-md shadow-2xl border-2 border-krewup-light-blue",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "p-6 space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-krewup-blue to-krewup-orange shadow-lg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-3xl",
                                    children: "🎯"
                                }, void 0, false, {
                                    fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                    lineNumber: 347,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 346,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold bg-gradient-to-r from-krewup-blue to-krewup-orange bg-clip-text text-transparent",
                                children: "What brings you here?"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 349,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-sm text-gray-600",
                                children: "Choose your role"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 350,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                        lineNumber: 345,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    updateFormData({
                                        role: 'worker'
                                    });
                                    setStep(3);
                                },
                                className: `flex items-start gap-4 rounded-xl border-3 p-5 text-left transition-all duration-300 hover:scale-105 hover:shadow-xl ${formData.role === 'worker' ? 'border-krewup-blue bg-gradient-to-r from-blue-50 to-blue-100 shadow-lg' : 'border-gray-300 hover:border-krewup-blue'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-krewup-blue to-krewup-light-blue text-white shadow-lg",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "h-7 w-7",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 366,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                            lineNumber: 365,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 364,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "font-semibold text-gray-900",
                                                children: "I'm a Worker"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 375,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-sm text-gray-600",
                                                children: "Find jobs, showcase skills, and connect with employers"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 376,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 374,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 354,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    updateFormData({
                                        role: 'employer'
                                    });
                                    setStep(3);
                                },
                                className: `flex items-start gap-4 rounded-xl border-3 p-5 text-left transition-all duration-300 hover:scale-105 hover:shadow-xl ${formData.role === 'employer' ? 'border-krewup-orange bg-gradient-to-r from-orange-50 to-orange-100 shadow-lg' : 'border-gray-300 hover:border-krewup-orange'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-krewup-orange to-krewup-light-orange text-white shadow-lg",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "h-7 w-7",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 394,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                            lineNumber: 393,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 392,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "font-semibold text-gray-900",
                                                children: "I'm an Employer"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 403,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-sm text-gray-600",
                                                children: "Post jobs, find skilled workers, and build your team"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 404,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 402,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 382,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                        lineNumber: 353,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        variant: "outline",
                        onClick: ()=>setStep(1),
                        className: "w-full",
                        children: "Back"
                    }, void 0, false, {
                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                        lineNumber: 411,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-gray-300"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 416,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-krewup-blue"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 417,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-gray-300"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 418,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                        lineNumber: 415,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                lineNumber: 344,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
            lineNumber: 343,
            columnNumber: 7
        }, this);
    }
    // Step 3: Trade/Employer Type Selection
    if (step === 3) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
            className: "w-full max-w-md shadow-2xl border-2 border-krewup-light-blue",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "p-6 space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-krewup-blue to-krewup-orange shadow-lg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-3xl",
                                    children: formData.role === 'worker' ? '🔧' : '🏢'
                                }, void 0, false, {
                                    fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                    lineNumber: 432,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 431,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold bg-gradient-to-r from-krewup-blue to-krewup-orange bg-clip-text text-transparent",
                                children: formData.role === 'worker' ? "What's your trade?" : 'Tell us about your business'
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 434,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-sm text-gray-600",
                                children: formData.role === 'worker' ? 'Select your primary trade' : 'Help workers understand what you do'
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 437,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                        lineNumber: 430,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: [
                            formData.role === 'worker' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                        label: "Trade",
                                        options: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TRADES"].map((trade)=>({
                                                value: trade,
                                                label: trade
                                            })),
                                        value: formData.trade,
                                        onChange: (e)=>updateFormData({
                                                trade: e.target.value,
                                                sub_trade: ''
                                            }),
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 447,
                                        columnNumber: 17
                                    }, this),
                                    formData.trade && __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TRADE_SUBCATEGORIES"][formData.trade] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                        label: "Specialty (Optional)",
                                        options: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TRADE_SUBCATEGORIES"][formData.trade].map((subTrade)=>({
                                                value: subTrade,
                                                label: subTrade
                                            })),
                                        value: formData.sub_trade || '',
                                        onChange: (e)=>updateFormData({
                                                sub_trade: e.target.value
                                            })
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 456,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700 mb-1.5",
                                                children: "Bio (Optional)"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 468,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                className: "flex min-h-[100px] w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-krewup-blue focus:border-transparent disabled:cursor-not-allowed disabled:opacity-50",
                                                placeholder: "Tell employers about your experience and skills...",
                                                value: formData.bio || '',
                                                onChange: (e)=>updateFormData({
                                                        bio: e.target.value
                                                    })
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 471,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1.5 text-sm text-gray-500",
                                                children: "Briefly describe your experience and what you're looking for"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 477,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 467,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                        label: "Employer Type",
                                        options: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["EMPLOYER_TYPES"].map((type)=>({
                                                value: type,
                                                label: type.charAt(0).toUpperCase() + type.slice(1)
                                            })),
                                        value: formData.employer_type || '',
                                        onChange: (e)=>updateFormData({
                                                employer_type: e.target.value
                                            }),
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 484,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                        label: "Company/Business Name",
                                        type: "text",
                                        placeholder: "ABC Construction LLC",
                                        value: formData.company_name || '',
                                        onChange: (e)=>updateFormData({
                                                company_name: e.target.value
                                            }),
                                        helperText: "Your business name (will be shown on job postings)",
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 499,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                        label: "Trade Specialty",
                                        options: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TRADES"].map((trade)=>({
                                                value: trade,
                                                label: trade
                                            })),
                                        value: formData.trade,
                                        onChange: (e)=>updateFormData({
                                                trade: e.target.value,
                                                sub_trade: ''
                                            }),
                                        helperText: "What type of workers do you hire?",
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 509,
                                        columnNumber: 17
                                    }, this),
                                    formData.trade && __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TRADE_SUBCATEGORIES"][formData.trade] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                        label: "Sub-Specialty (Optional)",
                                        options: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TRADE_SUBCATEGORIES"][formData.trade].map((subTrade)=>({
                                                value: subTrade,
                                                label: subTrade
                                            })),
                                        value: formData.sub_trade || '',
                                        onChange: (e)=>updateFormData({
                                                sub_trade: e.target.value
                                            })
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 519,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700 mb-1.5",
                                                children: "Bio (Optional)"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 531,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                className: "flex min-h-[100px] w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-krewup-blue focus:border-transparent disabled:cursor-not-allowed disabled:opacity-50",
                                                placeholder: "Tell workers about your company and what you're looking for...",
                                                value: formData.bio || '',
                                                onChange: (e)=>updateFormData({
                                                        bio: e.target.value
                                                    })
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 534,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1.5 text-sm text-gray-500",
                                                children: "Briefly describe your company and hiring needs"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 540,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 530,
                                        columnNumber: 17
                                    }, this),
                                    formData.employer_type === 'contractor' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-6 p-4 border-2 border-blue-300 bg-blue-50 rounded-lg",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "font-semibold text-blue-900 mb-1",
                                                children: "Contractor License Required"
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 548,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-blue-800 mb-4",
                                                children: "To ensure platform trust and safety, you must upload your contractor license. You won't be able to post jobs until your license is verified (usually within 24-48 hours)."
                                            }, void 0, false, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 551,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-4 bg-white p-4 rounded-lg",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                        label: "License Type",
                                                        type: "text",
                                                        placeholder: "e.g., General Contractor License",
                                                        value: licenseData.license_type,
                                                        onChange: (e)=>setLicenseData({
                                                                ...licenseData,
                                                                license_type: e.target.value
                                                            }),
                                                        required: true,
                                                        helperText: "Your contractor license classification"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 557,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                        label: "License Number",
                                                        type: "text",
                                                        placeholder: "e.g., 123456",
                                                        value: licenseData.license_number,
                                                        onChange: (e)=>setLicenseData({
                                                                ...licenseData,
                                                                license_number: e.target.value
                                                            }),
                                                        required: true,
                                                        helperText: "Your state-issued license number"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 569,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                        label: "Issuing Authority",
                                                        type: "text",
                                                        placeholder: "e.g., California Contractors State License Board",
                                                        value: licenseData.issuing_authority,
                                                        onChange: (e)=>setLicenseData({
                                                                ...licenseData,
                                                                issuing_authority: e.target.value
                                                            }),
                                                        required: true,
                                                        helperText: "The organization that issued your license"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 581,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                        label: "Issuing State",
                                                        type: "text",
                                                        placeholder: "e.g., California",
                                                        value: licenseData.issuing_state,
                                                        onChange: (e)=>setLicenseData({
                                                                ...licenseData,
                                                                issuing_state: e.target.value
                                                            }),
                                                        required: true,
                                                        helperText: "State that issued your license"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 593,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                        label: "Date Issued",
                                                        type: "date",
                                                        value: licenseData.issue_date,
                                                        onChange: (e)=>setLicenseData({
                                                                ...licenseData,
                                                                issue_date: e.target.value
                                                            }),
                                                        required: true,
                                                        helperText: "When your license was issued"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 605,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                        label: "Expiration Date",
                                                        type: "date",
                                                        value: licenseData.expires_at,
                                                        onChange: (e)=>setLicenseData({
                                                                ...licenseData,
                                                                expires_at: e.target.value
                                                            }),
                                                        required: true,
                                                        helperText: "When your license expires"
                                                    }, void 0, false, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 616,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                className: "block text-sm font-medium text-gray-700 mb-2",
                                                                children: [
                                                                    "License Photo ",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-red-500",
                                                                        children: "*"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                        lineNumber: 629,
                                                                        columnNumber: 41
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                lineNumber: 628,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs text-gray-600 mb-3",
                                                                children: "Upload a clear photo of your contractor license (JPEG, PNG, WebP, or PDF - Max 5MB)"
                                                            }, void 0, false, {
                                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                lineNumber: 631,
                                                                columnNumber: 25
                                                            }, this),
                                                            !licensePreview ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                className: "flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex flex-col items-center justify-center pt-5 pb-6",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                                className: "w-8 h-8 mb-2 text-gray-400",
                                                                                fill: "none",
                                                                                stroke: "currentColor",
                                                                                viewBox: "0 0 24 24",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                    strokeLinecap: "round",
                                                                                    strokeLinejoin: "round",
                                                                                    strokeWidth: 2,
                                                                                    d: "M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                                    lineNumber: 644,
                                                                                    columnNumber: 33
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                                lineNumber: 638,
                                                                                columnNumber: 31
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                className: "mb-1 text-sm text-gray-500",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        className: "font-semibold",
                                                                                        children: "Click to upload"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                                        lineNumber: 652,
                                                                                        columnNumber: 33
                                                                                    }, this),
                                                                                    " or drag and drop"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                                lineNumber: 651,
                                                                                columnNumber: 31
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                className: "text-xs text-gray-500",
                                                                                children: "Image or PDF (MAX. 5MB)"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                                lineNumber: 654,
                                                                                columnNumber: 31
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                        lineNumber: 637,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: "file",
                                                                        className: "hidden",
                                                                        accept: "image/jpeg,image/jpg,image/png,image/webp,application/pdf",
                                                                        onChange: (e)=>{
                                                                            const file = e.target.files?.[0];
                                                                            if (file) {
                                                                                setLicenseFile(file);
                                                                                const reader = new FileReader();
                                                                                reader.onloadend = ()=>{
                                                                                    setLicensePreview(reader.result);
                                                                                };
                                                                                reader.readAsDataURL(file);
                                                                            }
                                                                        },
                                                                        required: true
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                        lineNumber: 656,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                lineNumber: 636,
                                                                columnNumber: 27
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "space-y-3",
                                                                children: [
                                                                    licenseFile?.type === 'application/pdf' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex items-center gap-3 p-4 bg-gray-50 rounded-lg border border-gray-200",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                                className: "w-10 h-10 text-red-500",
                                                                                fill: "currentColor",
                                                                                viewBox: "0 0 20 20",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                                    d: "M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                                    lineNumber: 679,
                                                                                    columnNumber: 35
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                                lineNumber: 678,
                                                                                columnNumber: 33
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "flex-1",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                        className: "text-sm font-medium text-gray-900",
                                                                                        children: licenseFile.name
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                                        lineNumber: 682,
                                                                                        columnNumber: 35
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                        className: "text-xs text-gray-500",
                                                                                        children: [
                                                                                            (licenseFile.size / 1024 / 1024).toFixed(2),
                                                                                            " MB"
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                                        lineNumber: 683,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                                lineNumber: 681,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                        lineNumber: 677,
                                                                        columnNumber: 31
                                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                        src: licensePreview,
                                                                        alt: "License preview",
                                                                        className: "w-full max-h-64 object-contain rounded-lg border border-gray-200"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                        lineNumber: 689,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                        type: "button",
                                                                        variant: "outline",
                                                                        onClick: ()=>{
                                                                            setLicenseFile(null);
                                                                            setLicensePreview(null);
                                                                        },
                                                                        className: "w-full",
                                                                        children: "Remove Photo"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                        lineNumber: 695,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                                lineNumber: 675,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                        lineNumber: 627,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                                lineNumber: 556,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 547,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true),
                            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg bg-red-50 border border-red-200 p-3",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-red-800",
                                    children: error
                                }, void 0, false, {
                                    fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                    lineNumber: 717,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 716,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        variant: "outline",
                                        onClick: ()=>setStep(2),
                                        disabled: isLoading,
                                        className: "flex-1",
                                        children: "Back"
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 722,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        onClick: handleSubmit,
                                        disabled: isLoading || (formData.role === 'worker' ? !formData.trade : !formData.employer_type || !formData.company_name || !formData.trade || formData.employer_type === 'contractor' && (!licenseData.license_type || !licenseData.license_number || !licenseData.issuing_authority || !licenseData.issuing_state || !licenseData.issue_date || !licenseData.expires_at || !licenseFile)),
                                        isLoading: isLoading || isUploadingLicense,
                                        className: "flex-1",
                                        children: isUploadingLicense ? 'Uploading License...' : 'Complete Setup'
                                    }, void 0, false, {
                                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                        lineNumber: 725,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 721,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                        lineNumber: 444,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-gray-300"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 752,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-gray-300"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 753,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-krewup-blue"
                            }, void 0, false, {
                                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                                lineNumber: 754,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                        lineNumber: 751,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
                lineNumber: 429,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/features/onboarding/components/onboarding-form.tsx",
            lineNumber: 428,
            columnNumber: 7
        }, this);
    }
}
_s(OnboardingForm, "val2ZkorLysXliss20JcA2j6A+s=");
_c = OnboardingForm;
var _c;
__turbopack_context__.k.register(_c, "OnboardingForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=255e76a8-d45b-2e76-af7e-76981cc2d204
//# sourceMappingURL=_1cb40269._.js.map